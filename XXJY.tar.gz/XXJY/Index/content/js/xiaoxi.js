$(function(){
	var userid;
	var touserid;
	getUserid()
	function getUserid(){
		userid=localStorage.getItem("Useridx");
		console.log(userid)
	}
	getToucherid()
	function getToucherid(){
		touserid=sessionStorage.getItem("Touserid");
		console.log(touserid)
	}
	$("#sendChat").click(function(){
		var inputText=$("#inputText").val();	
		console.log(inputText)
		if(inputText){
		var li=document.createElement("li");
		var ul=document.createElement("ul");
		var inputTextJS=document.getElementById("inputText")
		var span=document.createElement("span")
		var label=document.createElement("label");
		var chatUl=document.getElementsByClassName("chatUl")[0]
		var chatmsg=document.getElementsByClassName("chatmsg")[0]
		var main=document.getElementsByClassName("main")[0]
		$(span).append(inputText)
		$(li).append(span)
		$(li).append(label)
		/* $(ul).append(li) */
		ul.className="chatUl";
		$(".main").append(ul);
		main.lastChild.scrollIntoView();
		inputTextJS.value="";
		/* chatmsg.lastChild.scrollIntoView(); */
		Myajax("xiaoxi","GET","http://manage.woyaoxuexue.com/guns/app/addusermessage",
		{
			"fromuserid":userid,
			"touserid":touserid,
			"content":inputText
		},10000,function(msg){
			var sendstr=msg.responseText;
			console.log(sendstr)
			location.reload([true]);
		},function(code){
			
		});
		}else{
			alert("请输入内容")
		}
	})
});