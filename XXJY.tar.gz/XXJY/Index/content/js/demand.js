window.onload=function(){
	var AlltimeValue1=0;
	var AlltimeValue2=0;
	var AlltimeValue3=0;
	var AlltimeValue4=0;
	var AlltimeValue5=0;
	var AlltimeValue6=0;
	var AlltimeValue7=0;
	var timeValueA;
	var timeValueB;
	var OKTimeValue;
	var moneyA;
	var AllmeonyX=document.getElementById("AllmeonyX");
			/* 删除 */
			var DELX=document.getElementsByClassName("DEL");
			for(var p=0;p<DELX.length;p++){
				DELX[p].num=p;
				DELX[p].onclick=function(){
					var x=this.num;
					var flag=confirm("确认删除吗？");
					if(flag){
						var x=this.num;
						if(x==0){
							AlltimeValue1=0
						}else if(x==1){
							AlltimeValue2=0
						}else if(x==2){
							AlltimeValue3=0
						}else if(x==3){
							AlltimeValue4=0
						}else if(x==4){
							AlltimeValue5=0
						}else if(x==5){
							AlltimeValue6=0
						}else if(x==6){
							AlltimeValue7=0
						}
						console.log(AlltimeValue1);
						console.log(AlltimeValue2);
						console.log(AlltimeValue3);
						console.log(AlltimeValue4);
						console.log(AlltimeValue5);
						console.log(AlltimeValue6);
						console.log(AlltimeValue7);
						
						OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
						ClassTimeX.value="总课时："+OKTimeValue;
						moneyA=$("#AllmeonyB").val();
						AllmeonyX.value="总费用："+OKTimeValue*moneyA
					/* 	console.log(OKTimeValue)
						console.log(AllmeonyB) */
			var	ul=this.parentNode.parentNode;
				ul.parentNode.removeChild(ul);
		        ul=null;
		}
		}
	}
	/* console.log(timeArry) */
	var i;
	var h;
	var j;
	var k;
	var L;
	var ClassTimeX=document.getElementById("ClassTimeX")
	/* 添加 */
	AndX.onclick=function(){
			var AndX=document.getElementById("AndX");
			var boxX=document.getElementById("boxX");
			var ul=document.createElement("ul");
			var li1=document.createElement("li");
			var li2=document.createElement("li");
			var li3=document.createElement("li");
			var li4=document.createElement("li");
			var li5=document.createElement("li");
			var li6=document.createElement("li");
			var select=document.createElement("select");
			var optionA=document.createElement("option");
			var optionB=document.createElement("option");
			var optionC=document.createElement("option");
			var optionD=document.createElement("option");
			var optionE=document.createElement("option");
			var optionF=document.createElement("option");
			var optionG=document.createElement("option");
			var select1=document.createElement("select");
				select1.setAttribute("class","timeclass");
			var option1=document.createElement("option");
			var option2=document.createElement("option");
			var option3=document.createElement("option");
			var option4=document.createElement("option");
			var option5=document.createElement("option");
			var option6=document.createElement("option");
			var option7=document.createElement("option");
			var option8=document.createElement("option");
			var option9=document.createElement("option");
			var option10=document.createElement("option");
			var option11=document.createElement("option");
			var option12=document.createElement("option");
			var option13=document.createElement("option");
			var option14=document.createElement("option");
			var option15=document.createElement("option");
			var option16=document.createElement("option");
			var option17=document.createElement("option");
			var option18=document.createElement("option");
			var option19=document.createElement("option");
			var option20=document.createElement("option");
			var option21=document.createElement("option");
			var option22=document.createElement("option");
			var option23=document.createElement("option");
			var option24=document.createElement("option");
			var option25=document.createElement("option");
			var select2=document.createElement("select");
				select2.setAttribute("class","timeclass");
			var option11a=document.createElement("option");
			var option22a=document.createElement("option");
			var option33a=document.createElement("option");
			var option44a=document.createElement("option");
			var option55a=document.createElement("option");
			var option66a=document.createElement("option");
			var option77a=document.createElement("option");
			var option88a=document.createElement("option");
			var option99a=document.createElement("option");
			var option1010a=document.createElement("option");
			var option1111a=document.createElement("option");
			var option1212a=document.createElement("option");
			var option1313a=document.createElement("option");
			var option1414a=document.createElement("option");
			var option1515a=document.createElement("option");
			var option1616a=document.createElement("option");
			var option1717a=document.createElement("option");
			var option1818a=document.createElement("option");
			var option1919a=document.createElement("option");
			var option2020a=document.createElement("option");
			var option2121a=document.createElement("option");
			var option2222a=document.createElement("option");
			var option2323a=document.createElement("option");
			var option2424a=document.createElement("option");	
			var option2525a=document.createElement("option");	
			var img=document.createElement("img");
			    img.src="../Index/content/img/fixed_img/垃圾桶.png";
			var button=document.createElement("button");
			    button.setAttribute("class","DEL");
			var text1=document.createTextNode("起始时间：");
			var text2=document.createTextNode("—");
			var textA=document.createTextNode("周一");
			var textB=document.createTextNode("周二");
			var textC=document.createTextNode("周三");
			var textD=document.createTextNode("周四");
			var textE=document.createTextNode("周五");
			var textF=document.createTextNode("周六");
			var textG=document.createTextNode("周日");
			/* ddddddd */
			var texta=document.createTextNode("凌晨1点");
			var textb=document.createTextNode("凌晨2点");
			var textc=document.createTextNode("凌晨3点");
			var textd=document.createTextNode("凌晨4点");
			var texte=document.createTextNode("凌晨5点");
			var textf=document.createTextNode("凌晨6点");
			var textg=document.createTextNode("凌晨7点");
			var texth=document.createTextNode("上午8点");
			var texti=document.createTextNode("上午9点");
			var textj=document.createTextNode("上午10点");
			var textk=document.createTextNode("上午11点");
			var textm=document.createTextNode("中午12点");
			var textl=document.createTextNode("下午13点");
			var textn=document.createTextNode("下午14点");
			var texto=document.createTextNode("下午15点");
			var textp=document.createTextNode("下午16点");
			var textq=document.createTextNode("下午17点");
			var textr=document.createTextNode("下午18点");
			var texts=document.createTextNode("下午19点");
			var textt=document.createTextNode("夜晚20点");
			var textu=document.createTextNode("夜晚21点");
			var textv=document.createTextNode("夜晚22点");
			var textw=document.createTextNode("夜晚23点");
			var textx=document.createTextNode("午夜24点");
			var texty=document.createTextNode("开始时间");
			
			var texta1=document.createTextNode("凌晨1点");
			var textb2=document.createTextNode("凌晨2点");
			var textc3=document.createTextNode("凌晨3点");
			var textd4=document.createTextNode("凌晨4点");
			var texte5=document.createTextNode("凌晨5点");
			var textf6=document.createTextNode("凌晨6点");
			var textg7=document.createTextNode("凌晨7点");
			var texth8=document.createTextNode("上午8点");
			var texti9=document.createTextNode("上午9点");
			var textj10=document.createTextNode("上午10点");
			var textk11=document.createTextNode("上午11点");
			var textm12=document.createTextNode("中午12点");
			var textl13=document.createTextNode("下午13点");
			var textn14=document.createTextNode("下午14点");
			var texto15=document.createTextNode("下午15点");
			var textp16=document.createTextNode("下午16点");
			var textq17=document.createTextNode("下午17点");
			var textr18=document.createTextNode("下午18点");
			var texts19=document.createTextNode("下午19点");
			var textt20=document.createTextNode("夜晚20点");
			var textu21=document.createTextNode("夜晚21点");
			var textv22=document.createTextNode("夜晚22点");
			var textw23=document.createTextNode("夜晚23点");
			var textx24=document.createTextNode("午夜24点");
			var textx25=document.createTextNode("结束时间");
			option11a.appendChild(texta1)
			option22a.appendChild(textb2)
			option33a.appendChild(textc3)
			option44a.appendChild(textd4)
			option55a.appendChild(texte5)
			option66a.appendChild(textf6)
			option77a.appendChild(textg7)
			option88a.appendChild(texth8)
			option99a.appendChild(texti9)
			option1010a.appendChild(textj10)
			option1111a.appendChild(textk11)
			option1212a.appendChild(textm12)
			option1313a.appendChild(textl13)
			option1414a.appendChild(textn14)
			option1515a.appendChild(texto15)
			option1616a.appendChild(textp16)
			option1717a.appendChild(textq17)
			option1818a.appendChild(textr18)
			option1919a.appendChild(texts19)
			option2020a.appendChild(textt20)
			option2121a.appendChild(textu21)
			option2222a.appendChild(textv22)
			option2323a.appendChild(textw23)
			option2424a.appendChild(textx24)
			option2525a.appendChild(textx25)
			
			optionA.appendChild(textA);
			optionB.appendChild(textB);
			optionC.appendChild(textC);
			optionD.appendChild(textD);
			optionE.appendChild(textE);
			optionF.appendChild(textF);
			optionG.appendChild(textG);
			
			option1.appendChild(texta);
			option2.appendChild(textb);
			option3.appendChild(textc);
			option4.appendChild(textd);
			option5.appendChild(texte);
			option6.appendChild(textf);
			option7.appendChild(textg);
			option8.appendChild(texth);
			option9.appendChild(texti);
			option10.appendChild(textj);
			option11.appendChild(textk);
			option12.appendChild(textm);
			option13.appendChild(textl);
			option14.appendChild(textn);
			option15.appendChild(texto);
			option16.appendChild(textp);
			option17.appendChild(textq);
			option18.appendChild(textr);
			option19.appendChild(texts);
			option20.appendChild(textt);
			option21.appendChild(textu);
			option22.appendChild(textv);
			option23.appendChild(textw);
			option24.appendChild(textx);
			option25.appendChild(texty);
			
			 select.appendChild(optionA);
			 select.appendChild(optionB);
			 select.appendChild(optionC);
			 select.appendChild(optionD);
			 select.appendChild(optionE);
			 select.appendChild(optionF);
			 select.appendChild(optionG);
			 select.setAttribute("class","day");
			 select1.appendChild(option25)
			 select1.appendChild(option1)
			 select1.appendChild(option2)
			 select1.appendChild(option3)
			 select1.appendChild(option4)
			 select1.appendChild(option5)
			 select1.appendChild(option6)
			 select1.appendChild(option7)
			 select1.appendChild(option8)
			 select1.appendChild(option9)
			 select1.appendChild(option10)
			 select1.appendChild(option11)
			 select1.appendChild(option12)
			 select1.appendChild(option13)
			 select1.appendChild(option14)
			 select1.appendChild(option15)
			 select1.appendChild(option16)
			 select1.appendChild(option17)
			 select1.appendChild(option18)
			 select1.appendChild(option19)
			 select1.appendChild(option20)
			 select1.appendChild(option21)
			 select1.appendChild(option22)
			 select1.appendChild(option23)
			 select1.appendChild(option24)
			 
			 select2.appendChild(option2525a)
			 select2.appendChild(option11a)
			 select2.appendChild(option22a)
			 select2.appendChild(option33a)
			 select2.appendChild(option44a)
			 select2.appendChild(option55a)
			 select2.appendChild(option66a)
			 select2.appendChild(option77a)
			 select2.appendChild(option88a)
			 select2.appendChild(option99a)
			 select2.appendChild(option1010a)
			 select2.appendChild(option1111a)
			 select2.appendChild(option1212a)
			 select2.appendChild(option1313a)
			 select2.appendChild(option1414a)
			 select2.appendChild(option1515a)
			 select2.appendChild(option1616a)
			 select2.appendChild(option1717a)
			 select2.appendChild(option1818a)
			 select2.appendChild(option1919a)
			 select2.appendChild(option2020a)
			 select2.appendChild(option2121a)
			 select2.appendChild(option2222a)
			 select2.appendChild(option2323a)
			 select2.appendChild(option2424a)
			 
			 
			 li1.appendChild(select);
			 li2.appendChild(text1);
			 li3.appendChild(select1)
			 li4.appendChild(text2);
			 li5.appendChild(select2);
			 button.appendChild(img);
			 li6.appendChild(button);
			 ul.appendChild(li1)
			 ul.appendChild(li2)
			 ul.appendChild(li3)
			 ul.appendChild(li4)
			 ul.appendChild(li5)
			 ul.appendChild(li6)
			 ul.setAttribute("class","timeUL");
			boxX.appendChild(ul);
			var DEL=document.getElementsByClassName("DEL");
			for(var t=0;t<DEL.length;t++){
				DEL[t].num=t;
				DEL[t].onclick=function(){
					var r=this.num;
					
							var flag=confirm("确认删除吗？");
							if(flag){
								if(r==0){
									AlltimeValue1=0
								}else if(r==1){
									AlltimeValue2=0
								}else if(r==2){
									AlltimeValue3=0
								}else if(r==3){
									AlltimeValue4=0
								}else if(r==4){
									AlltimeValue5=0
								}else if(r==5){
									AlltimeValue6=0
								}else if(r==6){
									AlltimeValue7=0
								}
						var	ul=this.parentNode.parentNode;
							ul.parentNode.removeChild(ul);
						    ul=null;
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA
				/* console.log(OKTimeValue)
				console.log(AllmeonyB) */
				}
				}
			}
			
		var allTimeSelect=document.getElementsByClassName("timeclass");
		var timeUL=document.getElementsByClassName("timeUL");
			for(i=2;i<allTimeSelect.length-1;i++){
				select1.setAttribute("id","timeclass"+i+"");
				select2.setAttribute("id","timeclass"+(i+1)+"");
			}
			if(timeUL.length>7){
				alert("数量超载")
			}
		var AllDay=document.getElementsByClassName("day");
			for(i=2;i<=AllDay.length;i++){
				select.setAttribute("id","dayID"+i+"");
			}
		/* 2 */
			$("#timeclass2").change(function(){
				timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
				timeValueH=$("#timeclass"+i+"").find("option:selected").text();
				AlltimeValue2=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
		if(isNaN(AlltimeValue2)){
			AlltimeValue2=0
		}
		/* console.log(AlltimeValue2) */
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		ClassTimeX.value="总课时："+OKTimeValue;
		moneyA=$("#AllmeonyB").val();
		AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				$("#timeclass3").change(function(){
				timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
				timeValueH=$("#timeclass"+i+"").find("option:selected").text();
				AlltimeValue2=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			 if(isNaN(AlltimeValue2)){
				AlltimeValue2=0
			}
			/* console.log(AlltimeValue2) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
			});
			});
			
		/* 3 */	
			$("#timeclass4").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue3=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			if(isNaN(AlltimeValue3)){
				AlltimeValue3=0
			}
			/* console.log(AlltimeValue3) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass5").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue3=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				 if(isNaN(AlltimeValue3)){
					AlltimeValue3=0
				}
				/* console.log(AlltimeValue2) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			/* 4 */
			
			$("#timeclass6").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue4=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			if(isNaN(AlltimeValue4)){
				AlltimeValue4=0
			}
			/* console.log(AlltimeValue4) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass7").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue4=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				 if(isNaN(AlltimeValue4)){
					AlltimeValue4=0
				}
				/* console.log(AlltimeValue4) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			/* 5 */
			$("#timeclass8").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue5=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			if(isNaN(AlltimeValue5)){
				AlltimeValue5=0
			}
			/* console.log(AlltimeValue5) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass9").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue5=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				 if(isNaN(AlltimeValue5)){
					AlltimeValue5=0
				}
				/* console.log(AlltimeValue5) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			
			
			/* 6 */
			
			$("#timeclass10").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue6=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			if(isNaN(AlltimeValue6)){
				AlltimeValue6=0
			}
			console.log(AlltimeValue6)
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass11").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue6=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				 if(isNaN(AlltimeValue6)){
					AlltimeValue6=0
				}
				/* console.log(AlltimeValue6) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			
			
			
			
			/* 7 */
			
			$("#timeclass12").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue7=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			if(isNaN(AlltimeValue7)){
				AlltimeValue7=0
			}
			/* console.log(AlltimeValue7) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass13").change(function(){
					timeValueX=$("#timeclass"+(i-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+i+"").find("option:selected").text();
					AlltimeValue7=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				 if(isNaN(AlltimeValue2)){
					AlltimeValue7=0
				}
				/* console.log(AlltimeValue7) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			
			
			
			
			
			
			
			
			};
			
	/* 按钮 */
	var ButtonZ=document.getElementsByClassName("ButtonZ");
		ButtonZ[0].onclick=function(){
			ButtonZ[0].style.backgroundColor="#1dacfa";
			ButtonZ[0].checked=true;
			ButtonZ[1].style.backgroundColor="#ffffff"
			ButtonZ[1].checked=false;
	};
	ButtonZ[1].onclick=function(){
			ButtonZ[1].style.backgroundColor="#1dacfa";
			ButtonZ[1].checked=true;
			ButtonZ[0].style.backgroundColor="#FFFFFF"
			ButtonZ[0].checked=false;
	}
	/* 1 */
	$("#timeclass0").change(function(){
		timeValueA=$("#timeclass0").find("option:selected").text();
		timeValueB=$("#timeclass1").find("option:selected").text();
	AlltimeValue1=parseInt(timeValueB.substring(2))-parseInt(timeValueA.substring(2));
	if(isNaN(AlltimeValue1)){
		AlltimeValue1=0
	}
	OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
	ClassTimeX.value="总课时："+OKTimeValue;
	moneyA=$("#AllmeonyB").val();
	AllmeonyX.value="总费用："+OKTimeValue*moneyA
	console.log(OKTimeValue)
	console.log(AllmeonyB)
		$("#timeclass1").change(function(){
			timeValueA=$("#timeclass0").find("option:selected").text();
		timeValueB=$("#timeclass1").find("option:selected").text();
	AlltimeValue1=parseInt(timeValueB.substring(2))-parseInt(timeValueA.substring(2));
	if(isNaN(AlltimeValue1)){
		AlltimeValue1=0
	}
	OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
	ClassTimeX.value="总课时："+OKTimeValue;
	moneyA=$("#AllmeonyB").val();
	AllmeonyX.value="总费用："+OKTimeValue*moneyA
	console.log(OKTimeValue)
	console.log(AllmeonyB)
	})
	})
	/* 钱钱钱 */
	$("#AllmeonyB").change(function(){
	    moneyA=$("#AllmeonyB").val();
		AllmeonyX.value="总费用："+OKTimeValue*moneyA
		/* console.log(OKTimeValue)
		console.log(AllmeonyB) */
	})
	}