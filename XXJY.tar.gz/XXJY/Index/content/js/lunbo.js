
    /* banner */
    var lunbotulist=document.getElementsByClassName("lunbotu");
    var list=document.getElementsByClassName("list");
    var index=0;
    for(var i=0;i < lunbotulist.length;i++){
        lunbotulist[i].className="lunbotu";
        list[i].style.background="whitesmoke";
			/* lunbotulist[i].style.display="none"; */
    }
    lunbotulist[index].className= lunbotulist[index].className + " LboC"; /* 0 1 2 3 0 1 2 3 */
    list[index].style.background="#337ab7";
    /* lunbotulist[index].style.display="block"; */
    var time=setInterval(function(){
        if(index < lunbotulist.length-1){
            index++; /*-1 0 1 2 0 1 2 */   /* index=++index��index=index++������*/
        }else{
            index=0; /* 0 0 */
        }
        for(var i=0;i < lunbotulist.length;i++){
            lunbotulist[i].className="lunbotu";
            list[i].style.background="whitesmoke";
			/* lunbotulist[i].style.display="none"; */
        }
        lunbotulist[index].className= lunbotulist[index].className + " LboC"; /* 0 1 2 3 0 1 2 3 */
        list[index].style.background="#337ab7";
		/* lunbotulist[index].style.display= "block"; */
    },2000);

    for(var j=0;j<list.length;j++){
        list[j].num=j;
        list[j].onclick=function(){
            var x=this.num;
            for(var i=0;i < lunbotulist.length;i++){
                list[i].style.background="whitesmoke";
                lunbotulist[i].className="lunbotu";
				/* lunbotulist[i].style.display="none"; */
            }
            list[x].style.backgroundColor="#337ab7";
            list[x]=lunbotulist[x].className=lunbotulist[x].className + " LboC";
			/* list[x]=lunbotulist[x].style.display="block"; */
        };
    }
	
	
	var bannerFirst=document.getElementById("bannerFirst");
	var bannerSecond=document.getElementById("bannerSecond");
	var bannerthird=document.getElementById("bannerthird");
	
	var bannerFirstUrl=document.getElementById("bannerFirstUrl");
	var bannerSecondUrl=document.getElementById("bannerSecondUrl");
	var bannerthirdUrl=document.getElementById("bannerthirdUrl");
	Myajax("getbanner","GET","http://manage.woyaoxuexue.com/guns/app/getbanner",
	{
		
	},10000,function(msg){
		var bannerstr=msg.responseText;
		/* console.log(bannerstr); */
		var bannerobj=JSON.parse(bannerstr)
		/* var bannerobj=eval("("+bannerstr+")"); */
		console.log(bannerobj);
		var bannerLength=bannerobj.data.length;
		/* console.log(bannerLength); */
		for(var i=0;i<bannerLength;i++){
			var bannerImgFirst=bannerobj.data[0].picurl;
			var bannerImgSecond=bannerobj.data[1].picurl;
			var bannerImgthird=bannerobj.data[2].picurl;
			
			var bannerUrlFirst=bannerobj.data[0].piclink;
			var bannerUrlSecond=bannerobj.data[1].piclink;
			var bannerUrlthird=bannerobj.data[2].piclink;
			
		}
		
		console.log(bannerImgFirst);
		bannerFirst.src=bannerImgFirst
		bannerSecond.src=bannerImgSecond
		bannerthird.src=bannerImgthird
		
		bannerFirstUrl.href=bannerUrlFirst
		bannerSecondUrl.href=bannerUrlSecond
		bannerthirdUrl.href=bannerUrlthird
	},function(code){
		
	})
	