function setCookie(key,value,timeDay,path,domain){
	var loseTime;
	var index=window.location.pathname.lastIndexOf("/");
	var currentPath=window.location.pathname.slice(0,index);
	domain=domain||document.domain;
	path=path || currentPath;
	if(!timeDay){
		document.cookie=key+"="+value+";path="+path+";domain="+domain+";"
	}
	loseTime=new Date();
	loseTime.setDate(loseTime.getDate()+timeDay);
	document.cookie=key+"="+value+";expires="+loseTime.toGMTString()+";path="+path+";domain="+domain+";"
}
  
function getCookie(key){
	if(document.cookie.length>0){
	var Cook=document.cookie.split(";");
	for(var i=0;i<Cook.length;i++){
		var temp=Cook[i].split("=");
		if(temp[0].trim()===key){
			return temp[1];
		}
	}
	}else{
		return "";
	}
}

function delCookie(key,path){
	setCookie(key,getCookie(key),-1,path);
}