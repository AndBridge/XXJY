		var userid;
		var technicianid;
		var imageurla;
		var imageurlb;
		var imageurlc;
		var imageurld;
		var addprovincenameValue;
		var addprovinceList;
		var addprovincecode;
		var addcitynameValue;
		var addcityList;
		var addcitycode;
		var parentidv;
		var parentid;
		var parentide;
		var parentidvh;
		var parentidh;
		var parentideh;
		var addareanameValue;
		var addareaList;
		var addareacode;
		
		var addprovincenameINNHTML;
		var addprovincename = document.getElementById("addprovincename");
		var ProvinceIDName=document.getElementsByClassName("ProvinceIDName")
		var addareaname = document.getElementById("addareaname")
		/* 省份地址 */
		getaddressProvince()
		function getaddressProvince() {
		Myajax("getaddressProvince","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
		{
			"parentid":100000,
			"leveltype":1,
		},100000,function(msg){
			var strq=msg.responseText;
			/* console.log(str); */
			var objc=eval("("+strq+")");
			/* console.log(objc); */
			addprovinceList=objc.data.length;
			for(var j=0;j<addprovinceList;j++){
			addprovincenameValue=objc.data[j].name;
			addprovincecode=objc.data[j].id
		/* console.log(addprovincecode); */
			/* console.log(addprovincenameValue); */
           addprovincenameINNHTML= "<option value=\""+addprovincecode+"\" class=\"ProvinceIDName\" >"+addprovincenameValue+"</option>";
			$("#addprovincename").append(addprovincenameINNHTML);
			/* console.log(ProvinceIDName[j].value) */
			}
			$("#addprovincename").change(function(){
		$("#addcityname").empty()
		parentid=$("#addprovincename").find("option:selected").val()
		parentidh=$("#addprovincename").find("option:selected").text()
		/* console.log(parentidh) */
			/* console.log(parentid) */
		GETaddcityname();
		
			})
		},function(code){
			console.log(code.status);
		})
		};
	
		/* 城市 */	
		
		function GETaddcityname(){
			Myajax("getaddCITYress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentid,
				"leveltype":2,
			},100000,function(msg){
				var strq=msg.responseText;
				// console.log(str);
				var objd=eval("("+strq+")");
				/* console.log(objd); */                                                    
				addcityList=objd.data.length;
				for(var j=0;j<addcityList;j++){
				addcitynameValue=objd.data[j].name;
				addcitycode=objd.data[j].id
		addcitynameINNHTML= "<option value=\""+addcitycode+"\">"+addcitynameValue+"</option>";
					$("#addcityname").append(addcitynameINNHTML);
				}
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				GETaddarea();
				$("#addareaname").empty();
				/* console.log(parentidvh) */
				$("#addcityname").change(function(){
				$("#addareaname").empty()
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				/* console.log(parentidvh) */
				GETaddarea();
				
					})
				
			},function(code){
				console.log(code.status);
			})
		}
		/* 地区 */
		function GETaddarea(){
			Myajax("getaddAREAress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentidv,
				"leveltype":3,
			},100000,function(msg){
				var stre=msg.responseText;
				// console.log(str);
				var obje=eval("("+stre+")");
				/* console.log(obje); */
				 /* console.log(str); */
				addareaList=obje.data.length;
				for(var j=0;j<addareaList;j++){
				addareanameValue=obje.data[j].name;
				addareacode=obje.data[j].id
		addareanameINNHTML= "<option value=\""+addareacode+"\">"+addareanameValue+"</option>";
					$("#addareaname").append(addareanameINNHTML);
				}
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				
				$("#addareaname").change(function(){
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				})
			},function(code){
				console.log(code.status);
			})
		}
		
			 
		  
		 
	//jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj
	GETtechnicianid()
	function GETtechnicianid(){
		localStorage .removeItem("TechnicianId");
		technicianid=localStorage.getItem("TechnicianId")
	}
	
	GETUERID()
	function GETUERID(){
	    userid = localStorage.getItem("Userid");
	};
	var confirm=document.getElementById("confirm");
			confirm.onclick=function(){
				/* console.log(userid); */
			var firstname=document.getElementById("firstname").value;
			/* console.log(firstname); */
			var secondname=document.getElementById("secondname").value;
			var cardid=document.getElementById("cardid").value;
			/* console.log(cardid) 12376817263847 */
			var cardpos=document.getElementById("uploadp").files[0];
			
			/* var REG=new RegExp("[a-zA-z]+://[^\s]*");
			var cardposURL=REG.exec(cardposIMG);
			var cardposURLString=String(cardposURL)
			var cardposURLString1=cardposURLString.split(")")[0];
			var cardposURLString2=String(cardposURLString1);
			var cardpos=cardposURLString2.split('"')[0]; */
			
			
			
			var cardneg=document.getElementById("uploadn").files[0];
			
			/* var cardnegURL=REG.exec(cardnegIMG);
			var cardnegURLString=String(cardnegURL)
			var cardnegURLString1=cardnegURLString.split(")")[0];
			var cardnegURLString2=String(cardnegURLString1);
			var cardneg=cardnegURLString2.split('"')[0]; */
			
			
			
			var gender=document.getElementsByName("tea_sex");
			var sex;
			if(gender[0].checked){
				sex="1";
			}else{
				sex="2";
			}
			var skillid=document.getElementById("xueke_pick").value;
			if(skillid=='种植'){
				skillid="1";
			}else if(skillid=='茶艺'){
				skillid="2";
			}else if(skillid=='维修'){
				skillid="3";
			}else if(skillid=='健身'){
				skillid="4";
			}else if(skillid=='舞蹈'){
				skillid="5";
			}else{
				skillid="0";
			}
			var price=document.getElementById("price").value;
			var title=document.getElementById("zhicheng_pick").value;
				if(title=='三级'){
					title="1";
				}else if(title=='二级'){
					title="2";
				}else if(title=='一级'){
					title="3";
				}else if(title=='高级'){
					title="4";
				}else if(title=='正高级'){
					title="5";
				}else{
					title="0";
				}
			var company=document.getElementById("danwei_pick").value;
			var placetype=document.getElementsByName("place");
			var address=document.getElementById("address").value;
			var teachplacetype;
			if(placetype[0].checked){
				teachplacetype="0";
			}else if(placetype[1].checked){
				teachplacetype="1";
			}else if(placetype[2].checked){
				teachplacetype="2";
			}else{
				teachplacetype=" ";
			}
			var phone=document.getElementById("phone").value;
			
			
			var photo=document.getElementById("uploadx").files[0];
			var shenhe=document.getElementById("uploadxs").files[0];
			var introduction=document.getElementById("introduction").value;
			/* console.log(cardpos) url("blob:http://127.0.0.1:8848/7b774dad-03ad-4f68-8836-54a40e4ec527") */
			/* console.log(cardneg) url("blob:http://127.0.0.1:8848/0537a241-bfe4-4aef-bf53-8e4fcc7b9adf") */
			
			
			
			
			
			
			
			/* headpicX=document.getElementById("upload").files[0]; */
			var formDataa = new FormData();
			formDataa.append('image', cardpos);
			$.ajax({
					async:false,//同步，异步
					url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
					type:"post",
					data:formDataa,
			                contentType: false,
			                processData: false,
			                mimeType: "multipart/form-data",
			                success: function (msg) {
			                  
							console.log(msg)
							imageurla=msg.data.imgurl;
							console.log(imageurla)
							
			                },
			                error: function (data) {
			                    console.log(data);
			                }
			            });
						
						
						var formDatab = new FormData();
						formDatab.append('image', cardneg);
						$.ajax({
								async:false,//同步，异步
								url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
								type:"post",
								data:formDatab,
						                contentType: false,
						                processData: false,
						                mimeType: "multipart/form-data",
						                success: function (msg) {
						                  
										console.log(msg)
										imageurlb=msg.data.imgurl;
										console.log(imageurlb)
										
						                },
						                error: function (data) {
						                    console.log(data);
						                }
						            });
									
									
									
									
									
									var formDatac = new FormData();
									formDatac.append('image', photo);
									$.ajax({
											async:false,//同步，异步
											url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
											type:"post",
											data:formDatac,
									                contentType: false,
									                processData: false,
									                mimeType: "multipart/form-data",
									                success: function (msg) {
									                  
													console.log(msg)
													imageurlc=msg.data.imgurl;
													console.log(imageurlc)
													
									                },
									                error: function (data) {
									                    console.log(data);
									                }
									            });
						
			var formDataa = new FormData();
			formDataa.append('image', shenhe);
			$.ajax({
					async:false,//同步，异步
					url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
					type:"post",
					data:formDataa,
			                contentType: false,
			                processData: false,
			                mimeType: "multipart/form-data",
			                success: function (msg) {
			                  
							console.log(msg)
							imageurld=msg.data.imgurl;
							console.log(imageurld)
							
			                },
			                error: function (data) {
			                    console.log(data);
			                }
			            });
						
			
			
			
			
			
			
			Myajax("userid","GET","http://manage.woyaoxuexue.com/guns/app/updatetechnicianinfo",
			{
				"technicianid":technicianid,
				"firstname":firstname,
				"secondname":secondname,
				"cardid":cardid,
				"cardpos":imageurla,
				"cardneg":imageurlb,
				"sex":sex,
				"skillid":skillid,
				"price":price,
				"title":title,
				"company":company,
				"teachplacetype":teachplacetype,
				"addprovincecode":parentid,
				"addprovincename":parentidh,
				"addcitycode":parentidv,
				"addcityname":parentidvh,
				"addareacode":parentide,
				"addareaname":parentideh,
				"address":address,
				"phone":phone,
				"photo":imageurlc,
				"introduction":introduction,
				"qualification":imageurld
			},100000,function(msg){
				var str=msg.responseText;
				var obja=eval("("+str+")");
				console.log(obja);
				console.log(userid);
				var msgoss=obja.msg;
				if(msgoss=="用户已加入学学"){
					alert(msgoss);
				}else if(msgoss=="用户加入失败！"){
					alert(msgoss);
				}else if(msgoss=="加入学学成功"){
					alert(msgoss+",信息变更，请重新登录");
					localStorage .removeItem("Userid");
					localStorage .removeItem("Useridx");
					localStorage .removeItem("userType");
					localStorage .removeItem("TecherId");
					localStorage .removeItem("TechnicianId");
					window.location.assign("../Mine/login.html");
				}
				
			},function(code){
				console.log(code.status);
			});
			}; 
			// $("#erroBtn").click(function(){
			// 	window.location.assign("../Join/jion.html");
			// })
			
			
			
			
			
			
			$("#erroBtn").click(function(){
				
					
					
						Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/deletetechnician",
						{
							"userid":userid
						},1000,function(msg){
							location.href="../Good_tea/zhiye.html"
						},function(code){
							
						})
					
					return false
					dropid.cancelBubble=true;//取消冒泡
				
			})