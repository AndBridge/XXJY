var idx;
var id;
var listLength;
var j;
var price;
var userid;
var allMoney;
var classnum;
var teacherIDX;
var skillid;
var technicianid;
getSkillId()
function getSkillId(){
    id = sessionStorage.getItem("ID");
 			getSkill();
}
useridx()
function useridx(){
	userid=localStorage.getItem("Userid");
	technicianid=localStorage.getItem("TechnicianId")
}


function getSkill(){
	Myajax("getSkill","GET","http://manage.woyaoxuexue.com/guns/app/getyxjsdetail",
	{
		"id":id
	},100000,
	function(msg){
		var str=msg.responseText;
		var obja=eval("("+str+")");
		console.log(obja);
		var firstname=obja.data.firstname+"老师";
		//console.log(firstname);
		idx=obja.data.id;
		teacherIDX=obja.data.userid;
		/* console.log(id); */
		/* userid=obja.data.userid; */
		/* console.log(userid); */
		var photo=obja.data.photo;
		//console.log(photo);
		var sex=obja.data.sex;
		//console.log(sex);
		skillid=obja.data.skillid;
		//console.log(skillid);
		var introduction=obja.data.introduction;
		//console.log(introduction);
		var integrate=obja.data.integrate;
		//console.log(integrate);
		price=obja.data.price;
		/* console.log(price); */
		var teachplacetype=obja.data.teachplacetype;
		/* console.log(teachplacetype); */
		var ssq=obja.data.ssq;
		/*技能 转化 */
		
		if(skillid==1){
			skillid="种植";
		}else if(skillid==2){
			skillid="茶艺"
		}else if(skillid==3){
			skillid="维修"
		}else if(skillid==4){
			skillid="健身"
		}else if(skillid==5){
			skillid="舞蹈"
		}
		//console.log(skillid)
		/* 性别转换 */
		
			if(sex==1){
			sex="男";
		}else if(sex==2){
			sex="女";
		}else if(sex==0){
			sex="无要求";
		}else{
			sex="出错了";
		}
		//console.log(sex)
		/* 上课方式转换 */		
			
		if(teachplacetype==0){
			teachplacetype="请老师上门";
		}else if(teachplacetype==1){
			teachplacetype="到老师指定地点";
		}else if(teachplacetype==2){
			teachplacetype="无要求";
		}
		var useridChat=obja.data.userid;
		/* var allmenoy;
		
		var ClassTime=document.getElementsByClassName("ClassTime");
			ClassTime.onmouseleave=function(){
			allmenoy=ClassTime.value*price;
			} */
			var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.jpg\" ></a></button><li>授课经验:"+integrate+"课时</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:</li><input type=\"number\" class=\"ClassTime\" value=\"\" id=\"demo\" onchange=\"money()\"/><li id=\"change\">总价:0元</li></ul><a><button onclick=\"ConfirmPay()\" type=\"button\">确认订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a id=\"ONUrl\" onclick=\"setTouserid("+useridChat+", \'"+firstname+","+photo+" \')\"><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+ssq+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
			$("#ONUrl").click(function(){
				if(getCookie("userid","/")){
				 		 window.location.assign("../Index/xiaoxi.html");
				}else{
				 		 window.location.assign("../Mine/login.1.html")
				}
			})
			
	},function(code){
		console.log(code.status);
	}
	);
};
function money(){
	//console.log("333");
	
	//console.log(ClassTime.demo.value);
	classnum=demo.value;
	allMoney=demo.value*price;
	if(allMoney<0){
		allMoney=0;
	}
	$("#change").text("总价:"+allMoney+"元");
}


function addCollect(){
	
if(getCookie("userid","/")){
	
	Myajax("collectionuserid","GET","http://manage.woyaoxuexue.com/guns/app/addcollection",
	{
		"collectionuserid":teacherIDX,
		"userid":userid,
		"usertype":2
	},100000,function(msg){
		var str=msg.responseText;
		var objb=eval("("+str+")");
		console.log(objb);
		console.log(userid)
	var msgor=objb.msg;
	var codeor=objb.code;
	if(codeor=="100000"){
	alert("收藏成功");
	window.location.assign("../Mine/P_collect.html")
	}else if(msgor=="已添加当前数据，请勿重复添加"){
		alert(msgor);
	}
	},function(code){
		console.log(code.status);
	})
	}else{
	window.location.assign("../Mine/login.1.html");
}

}


function ConfirmPay(){
	if(getCookie("userid","/")){
	if(skillid=="种植"){
		skillid="1";
	}else if(skillid=="茶艺"){
		skillid="2"
	}else if(skillid=="维修"){
		skillid="3"
	}else if(skillid=="健身"){
		skillid="4"
	}else if(skillid=="舞蹈"){
		skillid="5"
	}
	Myajax("ConfirmPay","GET","http://manage.woyaoxuexue.com/guns/app/addjishiorder",
	{
		"userid":userid,
		"technicianid":idx,
		"skillid":skillid,
		"price":price,
		"classnum":classnum,
		"amount":allMoney
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		var msgpay=objr.msg;
		var codepay=objr.code;
		if(msgpay=="添加用户技师需求失败"){
					 alert(msgpay)
		}else if(codepay=="100000"){
			 alert("支付成功");
			window.location.assign("../Mine/P_order5.html");
		}
	},function(code){
		console.log(code.status)
	})}else{
		window.location.assign("../Mine/login.1.html");
	}
}

	
function setTouserid(touserid,name,photo){
	sessionStorage.removeItem("Touserid");
	sessionStorage.removeItem("Name");
	sessionStorage.removeItem("Photo");
	sessionStorage.setItem("Touserid", touserid);
	sessionStorage.setItem("Name", name);
	sessionStorage.setItem("Photo", photo);
	//}
	}