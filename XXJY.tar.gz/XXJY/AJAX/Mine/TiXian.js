var userid;
var payaccount;
var accounttype;
var amount;
var username;
var TPay=document.getElementById("TPay");
getUserid()
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
}
TPay.onclick=function(){
amount=document.getElementById("moneyTixian").value;
payaccount=document.getElementById("account").value;
username=document.getElementById("accountname").value;

var checkbox1=document.getElementsByName("checkbox1");
if(checkbox1[0].checked){
	accounttype=2
}else if(checkbox1[1].checked){
	accounttype=1
}
console.log(accounttype)
Myajax("TiXian","GET","http://manage.woyaoxuexue.com/guns/app/addcashapply",
{
	 "userid":userid,
	 "payaccount":payaccount,
	 "accounttype":accounttype,
	 "username":username,
	 "amount":amount,
},10000,function(msg){
	var strPayT=msg.responseText;
	
	
	var objT=eval("("+strPayT+")")
	console.log(objT)
	var codea=objT.code;
	console.log(codea)
	if(codea==100000){
		alert("提现金额:"+amount+"（预计在3-5个工作日到账，请耐心等待）")
	}else{
		alert("提现申请失败")
	}
},function(code){
	var error=code.responseText;
	console.log(error)
})
}
