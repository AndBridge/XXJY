var rows = 9999;//每页数据条数
var page = 1;
var maxpage;
var userid;
function GETuserID(){
	console.log();
	userid=localStorage.getItem("Useridx");
	if(userid!=null&&userid!=0)
		goodTeacher();
}
function goodTeacher(){
				
				
				//数据获取
				$.ajax({
						async:false,//同步，异步
						url:"http://manage.woyaoxuexue.com/guns/app/getjishiorderlistbyuser", //请求的服务端地址
						data:{
						"page":1,
						"rows":rows,
						"userid":userid,
						},
						type:"get",
						dataType:"json",
						success:function(data){
						var straa=data.data;
						console.log(straa)
						maxpage = data.data.navigateLastPage;
						//console.log(maxpage);
						var teacherNum=data.data.list.length;						
						
						var i,j;
						for(i = 0;i < teacherNum;i++){
							
						//var id=data.data.list[i].id;
						//var techeridx=data.data.list[i].userid;
						
							var teacherFirstname=data.data.list[i].firstname;
							var skillname=data.data.list[i].skillname;
							var ordertype=data.data.list[i].ordertype;
							if(ordertype==0){
								ordertype="已取消";
							}
							else if(ordertype==1){
								ordertype="等待老师确认";
							}
							else if(ordertype==2){
								ordertype="待支付";
							}
							else if(ordertype==3){
								ordertype="已完成";
							}
							else if(ordertype==4){
								ordertype="进行中";
							}
							else if(ordertype==5){
								ordertype="待支付";
							}
							
							var teacherMark;
							var teacherIntegrate=data.data.list[i].integrate;
							
						
							//teacherIntegrate = data.data.list[i].integrate;
							if(data.data.list[i].mark == "5.00")
								teacherMark = "content/img/up_img/pingfen5.jpg";
							else if(data.data.list[i].mark == "4.00")
								teacherMark = "content/img/up_img/pingfen4.jpg";
							else if(data.data.list[i].mark == "3.00")
								teacherMark = "content/img/up_img/pingfen3.jpg";
							else if(data.data.list[i].mark == "2.00")
								teacherMark = "content/img/up_img/pingfen2.jpg";
							else if(data.data.list[i].mark == "1.00")
								teacherMark = "content/img/up_img/pingfen1.jpg";
								
							var teacherBox=	"<a href=\"javascript:void(0);\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\"content/img/up_img/tx1.jpg\" alt=\"\"/></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+teacherFirstname+"老师</p></div><div class=\"subject\"><p>"+skillname+"</p></div><div class=\"state\"><p>订单状态：</p></div><div class=\"states\"><p>"+ordertype+"</p></div><div class=\"tea_grade\"><span>评分：</span><img src=\""+teacherMark+"\" alt=\"\"/></div><div class=\"exercise\"><p>授课经验："+teacherIntegrate+"课时</p></div></div></a>";
							$(".need").append(teacherBox);
						
						}
						}
						});
						}
						
					
	
	
// 	function holdId(Id){
// 		sessionStorage.removeItem("ID");
// 		//if (typeof(Storage) !== "undefined") {
// 	    // 存储
// 		console.log(Id);
// 	    sessionStorage.setItem("ID", Id);
// 		//}
// 		//var jsId = window.sessionStorage;
// 		//jsId = Id;
// 	}
	
	
						