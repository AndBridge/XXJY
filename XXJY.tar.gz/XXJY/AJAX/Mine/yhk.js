var userid;
var payaccount;
var username;
var bankname;
getUserid()
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
}
/* var main=document.getElementsByClassName("main")[0]
var main=document.getElementById("mianAA") */

$("#addCard").click(function(){
	var addCardMsgStr="<div id=\"guanbi\" class=\"addCardMsg\"><label>请输入账号：</label><input type=\"number\" name=\"payaccount\" /><p>银行详细名称(支行)：</p><input type=\"text\" name=\"bankname\" /><p>真实姓名：</p><input type=\"text\" name=\"username\" /><span id=\"removecard\">关闭</span><a class=\"confircard\">确定</a></div>";
	$("#guanbi").remove()
	$("body").append(addCardMsgStr)
	
	/* console.log(main) */
	/* main.lastChild.scrollIntoView(); */
	$("#removecard").click(function(){
		$("#guanbi").remove()
	})
	$(".confircard").click(function(){
		var bankname=document.getElementsByName("bankname")[0].value
		var payaccount=document.getElementsByName("payaccount")[0].value
		var username=document.getElementsByName("username")[0].value
		console.log(bankname)
		console.log(payaccount)
		console.log(username)
		Myajax("addcard","GET","http://manage.woyaoxuexue.com/guns/app/addaccount",
		{
			"userid":userid,
			"accounttype":"3",
			"payaccount":payaccount,
			"username":username,
			"bankname":bankname
			
		},1000,function(msg){
			var addStr=msg.responseText;
			console.log(addStr)
			location.reload([true]);
		},function(code){
			
		})
		
	})
	
})

Myajax("addcard","GET","http://manage.woyaoxuexue.com/guns/app/getaccountlist",
		{
			"userid":userid,
			"accounttype":"3"
		},1000,function(msg){
			var addStr=msg.responseText;
			/* console.log(userid) */
			var cardObj=eval("("+addStr+")")
			console.log(cardObj)
			var dataLeng=cardObj.data.length;
			/* console.log(dataLeng) */
			for(var i=0;i<dataLeng;i++){
				
				var bankname=cardObj.data[i].bankname;
				var username=cardObj.data[i].username;
				var payaccount=cardObj.data[i].payaccount;
				var accountid=cardObj.data[i].accountid;
				
				if("undefined"==payaccount){
					payaccount="未知名账号"
				}
				if("undefined"==username){
					username="未知名姓名"
				}
				if("undefined"==bankname){
					bankname="未知名银行"
				}
				cardMStr="<div class=\"yhk\"><div class=\"cardImg\"><img src=\"content/img/fixed_img/银行卡.png\" ></div><div class=\"cardMsg\"><li>"+bankname+"</li><li style=\"font-size: 12px; color: skyblue\">储蓄卡</li><li>卡号："+payaccount+"</li></div></div>"
				
				$(".main").append(cardMStr)
			}
			
			
		},function(code){
			
		})
		
		
		
		