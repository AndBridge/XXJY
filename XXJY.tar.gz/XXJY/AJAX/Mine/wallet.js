var teacherid;
var technicianid
getUserid()
function getUserid(){
	teacherid=localStorage.getItem("TecherId");
	technicianid=localStorage.getItem("TechnicianId");
}
var balanceA=document.getElementById("balance");

if("undefined"==technicianid){
Myajax("change","GET","http://manage.woyaoxuexue.com/guns/app/getyxmsdetail",
{
	"id":teacherid
},10000,function(msg){
   var str=msg.responseText;
   /* console.log(str) */
	var obj=eval("("+str+")");
	console.log(obj)
	var balance=obj.data.balance;
	console.log(balance)
	if(balance){
		balanceA.innerText="￥"+balance
	}else{
		balanceA.innerText="￥0"
	}
	console.log(teacherid)
},function(code){
	
})
}else{
Myajax("change","GET","http://manage.woyaoxuexue.com/guns/app/getyxjsdetail",
{
	"id":technicianid
},10000,function(msg){
   var str=msg.responseText;
   console.log(str)
	var obj=eval("("+str+")");
	console.log(obj)
	var balance=obj.data.balance;
	console.log(balance)
	balanceA.innerText="￥"+balance
	console.log(technicianid)
},function(code){
	
})
}