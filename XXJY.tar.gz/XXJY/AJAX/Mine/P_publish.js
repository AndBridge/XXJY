var userid
var teacherid;
var id;
var HTMLURLX="../Mine/demand.html"
GETuserID()
function GETuserID(){
	userid=localStorage.getItem("Userid");
	teacherid=localStorage.getItem("TecherId")
	Pushile();
}
console.log(userid)


function Pushile(){
	
	Myajax("need_more","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
	{
		"page":1,
		"rows":9999,
		"userid":userid
	},10000,function(msg){
		var str=msg.responseText;
		/* console.log(str) */
		var obja=eval("("+str+")")
		console.log(obja)
		var HTMLURL="../Mine/order_condition2.html";
		var Htmlurel2="../Mine/order_condition1.html"
		var lengList=obja.data.list.length;
		/* console.log(lengList) */
		for(var i=0;i<lengList;i++){
			var gradeid
			gradeid=obja.data.list[i].gradeid;
			// console.log(gradeid)
			if(gradeid=="小学"){
				gradeid = "1";
		}else if(gradeid=="2"){
				gradeid = "初中";
		}else if(gradeid=="3"){
			gradeid = "高中";
		}else if(gradeid=="0"){
			gradeid = "全学段";
		}
	console.log(gradeid)
				
		var orderno=obja.data.list[i].orderno		
				console.log(orderno)
		var nickname=obja.data.list[i].nickname	
				console.log(nickname)
				var courseid
		courseid=obja.data.list[i].courseid	
		var amount=obja.data.list[i].amount	
				
				if(courseid[0]=="1"){
					courseid="语文";
				}else if(courseid[0]=="2"){
					courseid="数学"
				}else if(courseid[0]=="3"){
					courseid="英语"
				}else if(courseid[0]=="4"){
					courseid="物理"
				}else if(courseid[0]=="5"){
					courseid="化学"
				}else if(courseid[0]=="6"){
					courseid="生物"
				}else if(courseid[0]=="7"){
					courseid="历史"
				}else if(courseid[0]=="8"){
					courseid="地理"
				}else if(courseid[0]=="9"){
					courseid="政治"
				}else if(courseid[0]=="10"){
					courseid="科学"
				}else if(courseid[0]=="11"){
					courseid="音乐"
				}else if(courseid[0]=="12"){
					courseid="美术"
				}else if(courseid[0]=="13"){
					courseid="体育"
				}else if(courseid[0]=="14"){
					courseid="信息"
				}else if(courseid[0]=="0"){
					courseid="全学科"
				}
				console.log(courseid)	
					var totaltime=obja.data.list[i].totaltime;
					var mark;
					mark=obja.data.list[i].mark
						
						if(mark == "5.00")
							mark = "content/img/up_img/pingfen5.jpg";
						else if(mark == "4.00")
							mark = "content/img/up_img/pingfen4.jpg";
						else if(mark == "3.00")
							mark = "content/img/up_img/pingfen3.jpg";
						else if(mark == "2.00")
							mark = "content/img/up_img/pingfen2.jpg";
						else if(mark == "1.00")
							mark = "content/img/up_img/pingfen1.jpg";
						
						var headpic=obja.data.list[i].headpic
						
			id=obja.data.list[i].id			
				console.log(id)	
				var ordertype;
			ordertype=obja.data.list[i].ordertype		
			if ( ordertype== 0) {
				ordertype="订单已取消"
				var PushileValue="<div class=\"publish\"><a href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+nickname+"</p></div><div class=\"subject\"><p>"+courseid+"|"+gradeid+"</p></div><div class=\"wrl\"><p>"+ordertype+"</p></div><div class=\"tea_grade\"><br><span>总课时："+totaltime+"课时</span></div><div class=\"exercise\">&nbsp;&nbsp;<br><p>&nbsp;&nbsp;&nbsp;总费用："+amount+"元</p></div></div></a></div>"
				$(".CONmain").append(PushileValue)
			} else if ( ordertype== 1) {
				ordertype="订单已发布"
				var PushileValue="<div class=\"publish\"><a href=\""+HTMLURLX+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+nickname+"</p></div><div class=\"subject\"><p>"+courseid+"|"+gradeid+"</p></div><div class=\"wrl\"><p>"+ordertype+"</p></div><div class=\"tea_grade\"><br><span>总课时："+totaltime+"课时</span></div><div class=\"exercise\">&nbsp;&nbsp;<br><p>&nbsp;&nbsp;&nbsp;总费用："+amount+"元</p></div></div></a></div>"
				$(".CONmain").append(PushileValue)
			} else if(ordertype== 2){
				ordertype="订单已领取"
				var PushileValue="<div class=\"publish\"><a href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+nickname+"</p></div><div class=\"subject\"><p>"+courseid+"|"+gradeid+"</p></div><div class=\"wrl\"><p>"+ordertype+"</p></div><div class=\"tea_grade\"><br><span>总课时："+totaltime+"课时</span></div><div class=\"exercise\">&nbsp;&nbsp;<br><p>&nbsp;&nbsp;&nbsp;总费用："+amount+"元</p></div></div></a></div>"
				$(".CONmain").append(PushileValue)
			}else if(ordertype== 3){
				ordertype="订单已完成"
				var PushileValue="<div class=\"publish\"><a href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+nickname+"</p></div><div class=\"subject\"><p>"+courseid+"|"+gradeid+"</p></div><div class=\"wrl\"><p>"+ordertype+"</p></div><div class=\"tea_grade\"><br><span>总课时："+totaltime+"课时</span></div><div class=\"exercise\">&nbsp;&nbsp;<br><p>&nbsp;&nbsp;&nbsp;总费用："+amount+"元</p></div></div></a></div>"
				$(".CONmain").append(PushileValue)
			}else if(ordertype== 4){
				ordertype="订单进行中"
				var PushileValue="<div class=\"publish\"><a href=\""+Htmlurel2+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+nickname+"</p></div><div class=\"subject\"><p>"+courseid+"|"+gradeid+"</p></div><div class=\"wrl\"><p>"+ordertype+"</p></div><div class=\"tea_grade\"><br><span>总课时："+totaltime+"课时</span></div><div class=\"exercise\">&nbsp;&nbsp;<br><p>&nbsp;&nbsp;&nbsp;总费用："+amount+"元</p></div></div></a></div>"
				$(".CONmain").append(PushileValue)
			}else if(ordertype== 5){
				ordertype="订单待支付"
			var PushileValue="<div class=\"publish\"><a  onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+nickname+"</p></div><div class=\"subject\"><p>"+courseid+"|"+gradeid+"</p></div><div class=\"wrl\"><p>"+ordertype+"</p></div><div class=\"tea_grade\"><br><span>总课时："+totaltime+"课时</span></div><div class=\"exercise\">&nbsp;&nbsp;<br><p>&nbsp;&nbsp;&nbsp;总费用："+amount+"元</p></div></div></a></div>"
			$(".CONmain").append(PushileValue)
			}
				console.log(ordertype)	
			
				console.log(totaltime)	
		
					
					
		}
	},function(code){
		console.log(code.status);
	});
	
	}
	
	function holdId(Id){
		localStorage.removeItem("ID");
		//if (typeof(Storage) !== "undefined") {
	    // 存储
		console.log(Id);
	    localStorage.setItem("ID", Id);
		//}
		//var jsId = window.sessionStorage;
		//jsId = Id;
	}
	