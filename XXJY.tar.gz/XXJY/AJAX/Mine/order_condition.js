var id;
var listLength;
var j;
var price;
var courseid;
var gradeid;
var userid;
//var teacherIDX;
var allMoney;
var classnum;
var teacherid;
var orderid;
var ordertype;
GetorderID()
function GetorderID(){
//     userid = localStorage.getItem("Userid");
// 	//id = Id;
// 	/* console.log(userid); */
// 	teacherid=localStorage.getItem("TecherId");
	orderid=localStorage.getItem("OrderId");
	ordertype=localStorage.getItem("OrderType");
	console.log(orderid);
	console.log(ordertype);
	getTeacher();
}
// getTeacherID()
// function getTeacherID(){
//     id = sessionStorage.getItem("ID");
// 	//id = Id;
// 	console.log(id);
//  			getTeacher();
// }


function getTeacher(){
	/* console.log("1"); */
	Myajax("getTeacher","GET","http://manage.woyaoxuexue.com/guns/app/getmingshiorderdetail",
	{
		"page":1,
		"rows":99,
		"orderid":orderid,
	},100000,
	function(msg){
		var str=msg.responseText;
		/* console.log(str); */
		var obja=eval("("+str+")");
		console.log(obja);
		var firstname=obja.data.firstname;//昵称
		//console.log(firstname);
		/* var id=obja.data.id; */
		//console.log(id);
		//teacherIDX=obja.data.userid;
		//console.log(userid);
		var photo="..\\content\\img\\up_img\\tx1.jpg"
		//var photo=obja.data.list[0].headpic;//头像
		//console.log(photo);
		var sex=obja.data.sex;
		console.log(sex);
		courseid=obja.data.courseid;
		//console.log(courseid);
		var gradeid=obja.data.gradeid;
		/* console.log(gradeid); */
		var introduction=obja.data.introduction;
		if(introduction==null)
			introduction="无";
		//console.log(introduction);
		var integrate=obja.data.integrate;
		//console.log(integrate);
		price=obja.data.price;
		/* console.log(price); */
		var teachplacetype=obja.data.teachplacetype;
		/* console.log(teachplacetype); */
		ssq=obja.data.address;
		/*技能 转化 */
		var amount=obja.data.amount;
		var timeNum=obja.data.totaltime;
		var classnum=obja.data.classnum;
		//var time;
		
		
// 		for(var i=0;i<timeNum;i++){
// 			if(i==0){
// 				time="星期"+obja.data.list[0].timelist[i].week+"&nbsp,&nbsp"+obja.data.list[0].timelist[i].starttime+"->"+obja.data.list[0].timelist[i].endtime;
// 			}
// 			else{
// 				time=time+"</br>星期"+obja.data.list[0].timelist[i].week+"&nbsp,&nbsp"+obja.data.list[0].timelist[i].starttime+"->"+obja.data.list[0].timelist[i].endtime;
// 			}
// 		}
		var button="<a><button type=\"button\" disable=\"true\">订单已完成</button></a>";
		if(ordertype==5){
			button="<a><button onclick=\"ConfirmPay()\" type=\"button\">支付</button></a>";
		}
		else if(ordertype==4){
			button="<a><button onclick=\"ConfirmPay()\" type=\"button\">确认完成</button></a>";
		}
		else if(ordertype==3){
			button="<a><button  type=\"button\">订单已完成</button></a>";
		}
		else if(ordertype==2){
			button="<a><button type=\"button\">等待老师确认</button><button onclick=\"ConfirmPay()\" type=\"button\">取消订单</button></a>";
		}else if(ordertype==0){
			button="<a><button  type=\"button\">订单已取消</button></a>";
		}else if(ordertype==1){
			button="<a><button  type=\"button\">订单已发布</button></a>";
		}
		
		if(courseid=="1"){
			courseid="语文";
		}else if(courseid=="2"){
			courseid="数学"
		}else if(courseid=="3"){
			courseid="英语"
		}else if(courseid=="4"){
			courseid="物理"
		}else if(courseid=="5"){
			courseid="化学"
		}else if(courseid=="6"){
			courseid="生物"
		}else if(courseid=="7"){
			courseid="历史"
		}else if(courseid=="8"){
			courseid="地理"
		}else if(courseid=="9"){
			courseid="政治"
		}else if(courseid=="10"){
			courseid="科学"
		}else if(courseid=="11"){
			courseid="音乐"
		}else if(courseid=="12"){
			courseid="美术"
		}else if(courseid=="13"){
			courseid="体育"
		}else if(courseid=="14"){
			courseid="信息"
		}else if(courseid=="0"){
			courseid="全学段"
		}
		//console.log(skillid)
		/* 性别转换 */
		
			if(sex=="1"){
			sex="男";
		}else if(sex=="2"){
			sex="女";
		}else if(sex=="0"){
			sex="无要求";
		}else{
			sex="出错了";
		}
		//console.log(sex)
		/* 上课方式转换 */		
			
		if(teachplacetype=="0"){
			teachplacetype="请老师上门";
		}else if(teachplacetype=="1"){
			teachplacetype="到老师指定地点";
		}else if(teachplacetype=="2"){
			teachplacetype="无要求";
		}
		/* 年级转换 */
		if(gradeid=="1"){
			gradeid="小学";
		}else if(gradeid=="2"){
			gradeid="初中";
		}else if(gradeid=="3"){
			gradeid="高中";
		}else if(gradeid=="0"){
			gradeid="全学段";
		}else{
			gradeid="出错了";
		}
		if(address==""){
			address="您没有填写地址，请核实您的授课方式"
		}
		if(!address){
			address="您没有填写地址，请核实您的授课方式"
		}
		if(address="undefined undefined undefined"){
			address="您没有填写地址，请核实您的授课方式"
		}
		
		if(addareaname==""){
			addareaname="您没有填写地址，请核实您的授课方式"
		}
		if(!addareaname){
			addareaname="您没有填写地址，请核实您的授课方式"
		}
		if(!addareaname=="undefined"){
			addareaname="您没有填写地址，请核实您的授课方式"
		}
		if(addareaname=="undefined undefined undefined"){
			addareaname="您没有填写地址，请核实您的授课方式"
		}
		
		/* var allmenoy;
		
		var ClassTime=document.getElementsByClassName("ClassTime");
			ClassTime.onmouseleave=function(){
			allmenoy=ClassTime.value*price;
			} */
			//<ul><li>计划课时安排</li><p>"+time+"</p><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li id=\"change\">总价:"+amount+"</li></ul>
			
			var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button onclick=\"addCollect()\" type=\"button\"><a><img src=\"content/img/fixed_img/点击收藏.png\" >点击收藏</a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"</li><li id=\"change\">总价:"+amount+"</li></ul>"+button+"";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+photo+"\"></form></div><a ><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+ssq+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
	},function(code){
		console.log(code.status);
	}
	);
};
function money(){
	//console.log("333");
	classnum=demo.value;
	//console.log(ClassTime.demo.value);
	allMoney=demo.value*price;
	if(allMoney<0){
		allMoney=0;
	}
	$("#change").text("总价:"+allMoney);	
}


// function addCollect(){
// 	Myajax("collectionuserid","GET","http://manage.woyaoxuexue.com/guns/app/addcollection",
// 	{
// 		"collectionuserid":teacherIDX,
// 		"userid":userid,
// 		"usertype":1
// 	},100000,function(msg){
// 		var str=msg.responseText;
// 		var objb=eval("("+str+")");
// 		console.log(objb);
// 		console.log(userid)
// 		var msgoo=objb.msg;
// 		var codeoo=objb.code;
// 		if(codeoo=="100000"){
// 		alert("收藏成功");
// 		window.location.assign("../Mine/P_collect.html")
// 		}else if(msgoo=="已添加当前数据，请勿重复添加"){
// 			alert(msgoo);
// 		}
// 	},function(code){
// 		console.log(code.status);
// 	})
// }


function ConfirmPay(){
	if(courseid=="语文"){
		courseid="1";
	}else if(courseid=="数学"){
		courseid="2"
	}else if(courseid=="英语"){
		courseid="3"
	}else if(courseid=="物理"){
		courseid="4"
	}else if(courseid=="化学"){
		courseid="5"
	}else if(courseid=="生物"){
		courseid="6"
	}else if(courseid=="历史"){
		courseid="7"
	}else if(courseid=="地理"){
		courseid="8"
	}else if(courseid=="政治"){
		courseid="9"
	}
	Myajax("ConfirmPay","GET","http://manage.woyaoxuexue.com/guns/app/addmingshiorder",
	{
		"userid":userid,
		"teacherid":teacherIDX,
		"courseid":courseid,
		"price":price,
		"classnum":classnum,
		"amount":allMoney
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 var msgpay=objr.msg;
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("支付成功");
			 window.location.assign("../Index/index.html");
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}