var userid;
var addressAll=[];
var nicknameValueX;
var addressValueX;
var sexValueX;
var phonValueX;
var birthday;
var emailValueX;
var headpicX;
var nickname;
var address;
var sex;
var phone;
var imageurl;
var birthday;
var email;
var headpic;
getUserId();
function getUserId(){
	userid=localStorage.getItem("Userid");
	getUserContent();
}
function getUserContent(){
	Myajax("getUserContent","GET","http://manage.woyaoxuexue.com/guns/app/getuserinfo",
	{
		"userid":userid,
	},10000,function(msg){
		var stra=msg.responseText;
		/* console.log(stra); */
		var obja=eval("("+stra+")");
		console.log(obja);
		/* var ssq=obja.data.technicianinfo.ssq;
		console.log(ssq);
		addressAll=ssq.split(" "); */
		email=obja.data.email;
		/* console.log(email); */
		sex=obja.data.sex;
		if(sex==1){
			sex="男";
		}else if(sex==2){
			sex="女";
		}else if(sex==""){
			sex="性别";
		}
		nickname=obja.data.nickname;
		phone=obja.data.phone;
		address=obja.data.address;
		headpic=obja.data.headpic;
		console.log(headpic)
		if(typeof(headpic)=='undefined'){
			alert("请填写完整信息");
		}
		$("#pic").attr("src",headpic);
		$("#nicknameValue").empty();
		$("#nicknameValue").html(nickname);
		$("#sexValue").empty();
		$("#sex").val(sex);
		$("#phonValue").empty();
		$("#phonValue").html(phone);
				$("#emailValue").empty();
				$("#emailValue").html(email);
				$("#addressValue").empty();
				$("#addressValue").html(address);	
	},function(code){
		console.log(code.status);
	})
}

	
	$("#nickname").click(function(){
		nicknameValueX=prompt("请输入您的昵称","");
		if(nicknameValueX!=null && nicknameValueX!=""){
			$("#nicknameValue").empty();
			$("#nicknameValue").html(nicknameValueX)
		}
	})
	
	// $("#sex").click(function(){
		// sexValueX=prompt("请输入您的性别","");
		// if(sexValueX!=null && sexValueX!=""){
		// if(sexValueX=="男" || sexValueX=="女"){
		// 	$("#sexValue").empty();
		// 	$("#sexValue").html(sexValueX);
		// }else{
		// 	alert("请输入您正常的性别");
		// 	sexValueX=sex;
		// }
		$("#sex").change(function(){
			sexValueX=$("#sex").val();
			if(sexValueX=="男"){
				sexValueX=1;
			}else if(sexValueX=="女"){
				sexValueX=2;
			}else if(sexValueX=="性别"){
				sexValueX="";
			}
			console.log(sexValueX)
		})
		
		// }else{
		// 	alert("请输入您正常的性别");
		// 	sexValueX=sex;
		// }
	// })
	/* console.log(sexValueX); */
	$("#phone").click(function(){
		phonValueX=prompt("请输入您的手机号","");
		if(phonValueX!=null && phonValueX!=""){
			if((/^1[3456789]\d{9}$/.test(phonValueX))){
			   $("#phonValue").empty();
			   $("#phonValue").html(phonValueX);
			
			}else{
				phonValueX=phone;
				alert("请输入正确的手机号码")
			} 
		}else{
			alert("请输入正确的手机号码")
			phonValueX=phone;
		}
		   
	})
	
	$("#email").click(function(){
		emailValueX=prompt("请输入您的邮箱","");
		   /* if((/^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/.test(phonValueX))){ 
		       $("#emailValue").empty();
		       $("#emailValue").html(emailValueX);
		    
			}else{
				alert("请输入正确的邮箱")
			} */
			
			var t  = /^[A-Za-zd0-9]+([-_.][A-Za-zd]+)*@([A-Za-zd]+[-.])+[A-Za-zd]{2,5}$/;
			if(t.test(emailValueX)){
				$("#emailValue").empty();
				$("#emailValue").html(emailValueX);
			}else{
				alert("请输入正常的邮箱")
				emailValueX=email;
			}
			
	})
	
	$("#address").click(function(){
		addressValueX=prompt("请输入您的地址","");
		if(addressValueX!=null && addressValueX!=""){
			$("#addressValue").empty();
			$("#addressValue").html(addressValueX);
	}else{
		addressValueX=address;
	}
	})
	

	
	$("#BtnConfirm").click(function(){
		
	setUserContent();
	});
	function setUserContent(){
		
		headpicX=document.getElementById("SelectFile").files[0];
		console.log(headpicX)
		/* headpicX=headpicX.split("blob:")[1]; */		
		var formData = new FormData();
		
		formData.append('image', headpicX);
		$.ajax({
				async:false,//同步，异步
				url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
				type:"post",
				data:formData,
		                contentType: false,
		                processData: false,
		                mimeType: "multipart/form-data",
		                success: function (msg) {
		                    console.log(msg);
						imageurl=msg.data.imgurl;
						console.log(imageurl)
						
						
						
						
						
						if(typeof(nicknameValueX)=='undefined'){
							nicknameValueX=nickname;
						}
						if(typeof(sexValueX)=='undefined'){
							sexValueX=sex;
						}
						if(typeof(emailValueX)=='undefined'){
							emailValueX=email;
						}
						if(typeof(headpicX)=='undefined'){
							headpicWW=headpic;		
							imageurl=headpicWW;
						}
						if(typeof(addressValueX)=='undefined'){
							addressValueX=address;
						}
						if(typeof(phonValueX)=='undefined'){
							phonValueX=phone;
						}
						console.log(nicknameValueX)
						console.log(sexValueX)
						
						
						console.log(phonValueX)
						console.log(addressValueX)
						
						
						if(!emailValueX){
							emailValueX="";
						}
						if(!imageurl){
							imageurl="";
						}
						if(!nicknameValueX){
							nicknameValueX="";
						}
						if(!addressValueX){
							addressValueX="";
						}
						console.log(emailValueX)
						Myajax("getUserContent","GET","http://manage.woyaoxuexue.com/guns/app/updateuserinfo",
							{
								"userid":userid,
								"sex":sexValueX,
								"phone":phonValueX,
								"address":addressValueX,
								"email":emailValueX,
								"headpic":imageurl,
								"nickname":nicknameValueX
							},10000,function(msg){
								var stra=msg.responseText;
								console.log(stra);
								var timeva=setTimeout(function(){
									location.reload([true]);
									alert("修改成功");
								},500);
							},function(code){
								console.log(code.status);
							})
						
						
		                },
		                error: function (data) {
		                    console.log(data);
		                }
		            });
		
	}	
	
