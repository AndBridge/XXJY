var password;
var code1=Math.round(Math.random()*10);
var code2=Math.round(Math.random()*10);
var code3=Math.round(Math.random()*10);
var code4=Math.round(Math.random()*10);
var code5=Math.round(Math.random()*10);
var code6=Math.round(Math.random()*10);
var codex;
var codeh;
$("#sendss").click(function(){
	var account=$("#phone_number").val();
	if((/^1[3456789]\d{9}$/.test(account))){
	var code1=Math.round(Math.random()*10);
	var code2=Math.round(Math.random()*10);
	var code3=Math.round(Math.random()*10);
	var code4=Math.round(Math.random()*10);
	var code5=Math.round(Math.random()*10);
	var code6=Math.round(Math.random()*10);
	codex=code1.toString()+code2.toString()+code3.toString()+code4.toString()+code5.toString()+code6.toString();
	console.log(codex);
		Myajax("message","GET","http://manage.woyaoxuexue.com/guns/app/sendmessage",
		{
			"phone":account,
			"code":codex
		},10000,function(msg){
			var strb=msg.responseText;
			var objb=eval("("+strb+")");
			console.log(objb)
		},function(code){
			console.log(code.status)
		})

}else{
	alert("请输入正确的手机号码")
}
}
)
$("#btn").click(function(){
	var account=$("#phone_number").val();
	var password1=$("#password1").val();
	var password2=$("#password2").val();
	console.log(account)
	if(password1==password2){
		password=password1
		console.log(password)
		codeh=$("#telnum").val();
		console.log(codeh)
		console.log(codex)
		if(codex==codeh){
		Myajax("regist","GET","http://manage.woyaoxuexue.com/guns/app/reg",
		{
			"account":account,
			"password":password
		},10000,function(msg){
			var stra=msg.responseText;
			var obja=eval("("+stra+")");
			console.log(obja)
			var msg=obja.msg;
			if(msg=="该手机号已注册！"){
				alert(msg);
			}else if(msg=="参数密码为必需"){
				alert("请输入密码")
			}else if(msg=="用户创建成功"){
				alert(msg)
				window.location.assign("../Mine/login.html");
			}
			
		},function(code){
			console.log(code.status)
		})
		
		}else{
			alert("请输入正确的验证码");
		}
	}else{
		alert("请输入两次相同的密码")
	}
	
})

	

