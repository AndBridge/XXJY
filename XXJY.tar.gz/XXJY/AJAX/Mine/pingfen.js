var orderno;
var ordertype;
var mark;
var teacherid;
var technicianid;

$("#confirPJ").click(function(){
	PingFen()
})
function PingFen(){
	var markF=document.getElementsByName("fen");
	if(markF[0].checked){
			mark=1;
		}else if(markF[1].checked){
			mark=2;
		}else if(markF[2].checked){
			mark=3;
		}else if(markF[3].checked){
			mark=4;
		}else if(markF[4].checked){
			mark=5;
		}
		
	
		
	HuqALL()
	function HuqALL(){
		orderno=sessionStorage.getItem("OrderNO");
		teacherid=sessionStorage.getItem("Teacherid");
		technicianid=sessionStorage.getItem("Technicianid");
		
		if(technicianid==="undefined"){
		
		Myajax("PingFen","GET","http://manage.woyaoxuexue.com/guns/app/addevaluate",
		{
			"orderno":orderno,
			"ordertype":1,
			"mark":mark,
			"teacherid":teacherid
		},10000,function(msg){
			var str=msg.responseText;
			var obja=eval("("+str+")")
			var code=obja.code;
			console.log(obja)
			console.log(orderno)
			console.log(teacherid)
			console.log(mark)
			if(code==100000){
				alert("评价成功")
			}else{
				alert("出错了")
			}
		},function(code){
			console.log(code.status);
		})
		
		
		
		Myajax("PingFen","GET","http://manage.woyaoxuexue.com/guns/app/addevaluate",
		{
			"orderno":orderno,
			"ordertype":3,
			"mark":mark,
			"teacherid":teacherid
		},10000,function(msg){
			var str=msg.responseText;
			var obja=eval("("+str+")")
			var code=obja.code;
			console.log(obja)
			console.log(orderno)
			console.log(teacherid)
			
			
			console.log(mark)
			if(code==100000){
				alert("评价成功")
				window.location.assign("../Mine/P_order.html");
			}else{
				alert("出错了")
				window.location.assign("../Mine/P_order.html");
			}
		},function(code){
			console.log(code.status);
		})
		
			
		
		
		}else if(teacherid=="undefined"){
			
		Myajax("PingFen","GET","http://manage.woyaoxuexue.com/guns/app/addevaluate",
		{
			"orderno":orderno,
			"ordertype":2,
			"mark":mark,
			"technicianid":technicianid
		},10000,function(msg){
			var str=msg.responseText;
			var obja=eval("("+str+")")
			var code=obja.code;
			console.log(obja)
			console.log(orderno)
			console.log(teacherid)
			console.log(technicianid)
			
			console.log(mark)
			if(code==100000){
				alert("评价成功")
				window.location.assign("../Mine/P_order.html");
			}else{
				alert("出错了")
				window.location.assign("../Mine/P_order.html");
			}
		},function(code){
			console.log(code.status);
		})
		}
		}
		
	}
	
	
