					var addprovincenameValue;
					var addprovinceList;
					var addprovincecode;
					var addcitynameValue;
					var addcityList;
					var addcitycode;
					var parentidv;
					var parentid;
					var parentide;
					var parentidvh;
					var parentidh;
					var parentideh;
					var addareanameValue;
					var addareaList;
					var addareacode;
					var addprovincenameINNHTML;
					var addprovincename = document.getElementById("addprovincename");
					var ProvinceIDName=document.getElementsByClassName("ProvinceIDName")
					var addareaname = document.getElementById("addareaname")
					/* 省份地址 */
					getaddressProvince()
					function getaddressProvince() {
					Myajax("getaddressProvince","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
					{
						"parentid":100000,
						"leveltype":1,
					},100000,function(msg){
						var strq=msg.responseText;
						/* console.log(str); */
						var objc=eval("("+strq+")");
						/* console.log(objc); */
						addprovinceList=objc.data.length;
						for(var j=0;j<addprovinceList;j++){
						addprovincenameValue=objc.data[j].name;
						addprovincecode=objc.data[j].id
					/* console.log(addprovincecode); */
						/* console.log(addprovincenameValue); */
					   addprovincenameINNHTML= "<option value=\""+addprovincecode+"\" class=\"ProvinceIDName\" >"+addprovincenameValue+"</option>";
						$("#addprovincename").append(addprovincenameINNHTML);
						/* console.log(ProvinceIDName[j].value) */
						}
						$("#addprovincename").change(function(){
					$("#addcityname").empty()
					parentid=$("#addprovincename").find("option:selected").val()
					parentidh=$("#addprovincename").find("option:selected").text()
					/* console.log(parentidh) */
						/* console.log(parentid) */
					GETaddcityname();
					
						})
					},function(code){
						console.log(code.status);
					})
					};
						
					/* 城市 */	
					
					function GETaddcityname(){
						Myajax("getaddCITYress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
						{
							"parentid":parentid,
							"leveltype":2,
						},100000,function(msg){
							var strq=msg.responseText;
							// console.log(str);
							var objd=eval("("+strq+")");
							/* console.log(objd); */                                                    
							addcityList=objd.data.length;
							for(var j=0;j<addcityList;j++){
							addcitynameValue=objd.data[j].name;
							addcitycode=objd.data[j].id
					addcitynameINNHTML= "<option value=\""+addcitycode+"\">"+addcitynameValue+"</option>";
								$("#addcityname").append(addcitynameINNHTML);
							}
							parentidv=$("#addcityname").find("option:selected").val()
							parentidvh=$("#addcityname").find("option:selected").text()
							$("#addareaname").empty();
							GETaddarea();
							/* console.log(parentidvh) */
							$("#addcityname").change(function(){
							$("#addareaname").empty()
							parentidv=$("#addcityname").find("option:selected").val()
							parentidvh=$("#addcityname").find("option:selected").text()
							/* console.log(parentidvh) */
							GETaddarea();
							
								})
							
						},function(code){
							console.log(code.status);
						})
					}
					/* 地区 */
					function GETaddarea(){
						Myajax("getaddAREAress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
						{
							"parentid":parentidv,
							"leveltype":3,
						},100000,function(msg){
							var stre=msg.responseText;
							// console.log(str);
							var obje=eval("("+stre+")");
							/* console.log(obje); */
							 /* console.log(str); */
							addareaList=obje.data.length;
							for(var j=0;j<addareaList;j++){
							addareanameValue=obje.data[j].name;
							addareacode=obje.data[j].id
					addareanameINNHTML= "<option value=\""+addareacode+"\">"+addareanameValue+"</option>";
								$("#addareaname").append(addareanameINNHTML);
							}
							parentide=$("#addareaname").find("option:selected").val()
							parentideh=$("#addareaname").find("option:selected").text()
							//console.log(parentide) ;
							
							$("#addareaname").change(function(){
							parentide=$("#addareaname").find("option:selected").val()
							console.log(parentide);
							parentideh=$("#addareaname").find("option:selected").text()
							/* console.log(parentideh) */
							})
						},function(code){
							console.log(code.status);
						})
					}
///需要更改点击机构跳转的地址，筛选功能未做
var rows = 99;//每页数据条数
var page = 1;
var maxpage;
var orgId;
$('#more').hide();
function goodOrg(searchSsq){
				/* console.log("1"); */
				if(searchSsq == "省份 城市 区域")
					searchSsq = null;
				//数据获取
				$.ajax({
						async:false,//同步，异步
						url:"http://manage.woyaoxuexue.com/guns/app/getyxjglist", //请求的服务端地址
						data:{
						"page":page,
						"rows":rows,
						},
						type:"get",
						dataType:"json",
						beforeSend:function(){
						    $("#more").show();
						},
						
						success:function(data){
						// console.log("1");
						
						maxpage = data.data.navigateLastPage;
						//console.log(maxpage);
						var orgNum=data.data.list.length;
						//console.log(orgNum);//知道个数
						var orgName//机构名字
						var orgIntroduction//机构介绍
						var orgPopularity//机构人气数
						var orgImg//机构图片
						var orgSsq
						var temp1;
						var temp2;
						var temp3;
						var temp4;
						var shaixuan=document.getElementById("shaixuan_pick");
						temp1=$("#addprovincename");
						temp2=$("#addcityname");
						temp3=$("#addareaname");
						temp4=$("#btnsearch");
						 if(shaixuan.value=="人气"){
							$("#addareaname").remove()
							$("#addcityname").remove()
							$("#addprovincename").remove()
							$("#btnsearch").remove()
						}
						shaixuan.onchange=function(){
						if(shaixuan.value=="人气"){
							$("#addareaname").remove()
							$("#addcityname").remove()
							$("#addprovincename").remove()
							$("#btnsearch").remove()
						}else if(shaixuan.value=="距离"){
							$("#address").append(temp1)
							$("#address").append(temp2)
							$("#address").append(temp3)
							$("#address").append(temp4)
							var addprovincenameValue;
							var addprovinceList;
							var addprovincecode;
							var addcitynameValue;
							var addcityList;
							var addcitycode;
							var parentidv;
							var parentid;
							var parentide;
							var parentidvh;
							var parentidh;
							var parentideh;
							var addareanameValue;
							var addareaList;
							var addareacode;
							var addprovincenameINNHTML;
							var addprovincename = document.getElementById("addprovincename");
							var ProvinceIDName=document.getElementsByClassName("ProvinceIDName")
							var addareaname = document.getElementById("addareaname")
							/* 省份地址 */
							getaddressProvince()
							function getaddressProvince() {
							Myajax("getaddressProvince","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
							{
								"parentid":100000,
								"leveltype":1,
							},100000,function(msg){
								var strq=msg.responseText;
								/* console.log(str); */
								var objc=eval("("+strq+")");
								/* console.log(objc); */
								addprovinceList=objc.data.length;
								for(var j=0;j<addprovinceList;j++){
								addprovincenameValue=objc.data[j].name;
								addprovincecode=objc.data[j].id
							/* console.log(addprovincecode); */
								/* console.log(addprovincenameValue); */
							   addprovincenameINNHTML= "<option value=\""+addprovincecode+"\" class=\"ProvinceIDName\" >"+addprovincenameValue+"</option>";
								$("#addprovincename").append(addprovincenameINNHTML);
								/* console.log(ProvinceIDName[j].value) */
								}
								$("#addprovincename").change(function(){
							$("#addcityname").empty()
							parentid=$("#addprovincename").find("option:selected").val()
							parentidh=$("#addprovincename").find("option:selected").text()
							/* console.log(parentidh) */
								/* console.log(parentid) */
							GETaddcityname();
							
								})
							},function(code){
								console.log(code.status);
							})
							};
								
							/* 城市 */	
							
							function GETaddcityname(){
								Myajax("getaddCITYress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
								{
									"parentid":parentid,
									"leveltype":2,
								},100000,function(msg){
									var strq=msg.responseText;
									// console.log(str);
									var objd=eval("("+strq+")");
									/* console.log(objd); */                                                    
									addcityList=objd.data.length;
									for(var j=0;j<addcityList;j++){
									addcitynameValue=objd.data[j].name;
									addcitycode=objd.data[j].id
							addcitynameINNHTML= "<option value=\""+addcitycode+"\">"+addcitynameValue+"</option>";
										$("#addcityname").append(addcitynameINNHTML);
									}
									parentidv=$("#addcityname").find("option:selected").val()
									parentidvh=$("#addcityname").find("option:selected").text()
									$("#addareaname").empty();
									GETaddarea();
									/* console.log(parentidvh) */
									$("#addcityname").change(function(){
									$("#addareaname").empty()
									parentidv=$("#addcityname").find("option:selected").val()
									parentidvh=$("#addcityname").find("option:selected").text()
									/* console.log(parentidvh) */
									GETaddarea();
									
										})
									
								},function(code){
									console.log(code.status);
								})
							}
							/* 地区 */
							function GETaddarea(){
								Myajax("getaddAREAress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
								{
									"parentid":parentidv,
									"leveltype":3,
								},100000,function(msg){
									var stre=msg.responseText;
									// console.log(str);
									var obje=eval("("+stre+")");
									/* console.log(obje); */
									 /* console.log(str); */
									addareaList=obje.data.length;
									for(var j=0;j<addareaList;j++){
									addareanameValue=obje.data[j].name;
									addareacode=obje.data[j].id
							addareanameINNHTML= "<option value=\""+addareacode+"\">"+addareanameValue+"</option>";
										$("#addareaname").append(addareanameINNHTML);
									}
									parentide=$("#addareaname").find("option:selected").val()
									parentideh=$("#addareaname").find("option:selected").text()
									/* console.log(parentideh) */
									
									$("#addareaname").change(function(){
									parentide=$("#addareaname").find("option:selected").val()
									parentideh=$("#addareaname").find("option:selected").text()
									/* console.log(parentideh) */
									})
								},function(code){
									console.log(code.status);
								})
							}
						}
						} 
						
						var i,j;
						for(i = 0;i < orgNum;i++){
							orgId = data.data.list[i].id;
							//console.log(orgId);
							orgSsq = data.data.list[i].ssq;
							if(searchSsq != null && searchSsq != orgSsq)
								continue;
							orgName = data.data.list[i].organizationname;
							orgIntroduction = data.data.list[i].introduction;
							orgPopularity = data.data.list[i].popularity;
							orgImg = data.data.list[i].photo;
							
							var orgBox = "<a href=\"../Good_Org/youxuan.html\" onclick=\"holdId("+orgId+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"institutional_img \" ><img class=\"weui-media-box__thumb \" src=\"" +orgImg+ "\"></div><div class=\"weui-media-box__bd\"><h3 class=\"institutional_title\">"+ orgName +"</h3><p class=\"weui-media-box__desc\">"+ orgIntroduction +"</p><ul class=\"institutional_text\"><li class=\"weui-media-box__info__meta people_luck\">人气数：</li><li class=\"weui-media-box__info__meta\">"+ orgPopularity +"</li></ul></div></a>";
							$("#rank_list").append(orgBox);
						}
						}
						});
						
						
						$(window).scroll(
						        function() {
									//console.log("2");
						            var scrollTop = $(this).scrollTop();
						            var scrollHeight = $(document).height();
						            var windowHeight = $(this).height();
						            if (scrollTop + windowHeight == scrollHeight) {
						                //console.log("3");
						                if(page<maxpage) {
											page++;
						                    goodOrg();
										}
						                if(page==maxpage){
						                    $("#more").html("没有更多数据了");return false;
						                }
						                
						            }
						        });
						}
	
	
	function holdId(Id){
		sessionStorage.removeItem("OrgID");
		//if (typeof(Storage) !== "undefined") {
	    // 存储
		console.log(Id);
	    sessionStorage.setItem("OrgID", Id);
		//}
		//var jsId = window.sessionStorage;
		//jsId = Id;
	}
	
	
	function changePlace(){
		//console.log("333");
		$("#rank_list").empty();
		var province = $("#addprovincename").find("option:selected").text();
		var city = $("#addcityname").find("option:selected").text();
		var area = $("#addareaname").find("option:selected").text();
		var searchSsq = province+' '+city+' '+area;
		goodOrg(searchSsq);
		$("#more").html("没有更多数据了");
		//console.log(searchSsq);
	}
 /* function change(){
 					var shaixuan = document.getElementById("shaixuan_pick").value;
					var xuanZe;
					var Ren;
					var Juli;
				if(shaixuan=="人气"){
					
					goodOrg(0);
					$("#rank_list").empty();
				}else if(shaixuan=="距离"){
					
					goodOrg(1);
				$("#rank_list").empty();
				}
 				} */
				/* page = 1;
					goodOrg(); */
				
					
						var bannerFirst=document.getElementById("bannerFirst");
						var bannerSecond=document.getElementById("bannerSecond");
						var bannerthird=document.getElementById("bannerthird");
						
						var bannerFirstUrl=document.getElementById("bannerFirstUrl");
						var bannerSecondUrl=document.getElementById("bannerSecondUrl");
						var bannerthirdUrl=document.getElementById("bannerthirdUrl");
						Myajax("getbanner","GET","http://manage.woyaoxuexue.com/guns/app/getbanner",
						{
							
						},10000,function(msg){
							var bannerstr=msg.responseText;
							/* console.log(bannerstr); */
							var bannerobj=JSON.parse(bannerstr)
							/* var bannerobj=eval("("+bannerstr+")"); */
							console.log(bannerobj);
							var bannerLength=bannerobj.data.length;
							/* console.log(bannerLength); */
							for(var i=0;i<bannerLength;i++){
								var bannerImgFirst=bannerobj.data[0].picurl;
								var bannerImgSecond=bannerobj.data[1].picurl;
								var bannerImgthird=bannerobj.data[2].picurl;
								
								var bannerUrlFirst=bannerobj.data[0].piclink;
								var bannerUrlSecond=bannerobj.data[1].piclink;
								var bannerUrlthird=bannerobj.data[2].piclink;
								
							}
							
							console.log(bannerImgFirst);
							bannerFirst.src=bannerImgFirst
							bannerSecond.src=bannerImgSecond
							bannerthird.src=bannerImgthird
							
							bannerFirstUrl.href=bannerUrlFirst
							bannerSecondUrl.href=bannerUrlSecond
							bannerthirdUrl.href=bannerUrlthird
						},function(code){
							
						})
						 
					  