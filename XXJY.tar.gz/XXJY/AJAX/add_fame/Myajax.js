function resobj(obj){
		obj.t=new Date().getTime();  
	    var res=[];
		for(var Key in obj){
		res.push(encodeURIComponent(Key)+"="+encodeURIComponent(obj[Key]));
		}
		var resp=res.join("&");   
		return resp;
	};


	function Myajax(XmlName,Method,URLX,obj,Timeout,success,error){
	/* obj && obj; */
	var str=resobj(obj);      
	if(window.XMLHttpRequest){
	var XmlName=new XMLHttpRequest(); 
	}else{
	var XmlName=new ActiveXObject("Microsoft.XMLHTTP");
	}                               
	
	if(Method==="GET"){              
			XmlName.open(Method,URLX+"?"+str,true); 
			XmlName.send();       
	}else if (Method==="POST"){
		XmlName.open(Method,URLX,true);
		XmlName.setRequestHeader("Content-type","application/x-www-form-urlencoded");        
		XmlName.send(str);
	}else{
		console.log("出错了");
	}
	
	XmlName.onreadystatechange=function(){
		if(XmlName.readyState===4){   
			clearInterval(timex);
			if(XmlName.status>=200 && XmlName.status<300 || XmlName.status===304){
				success(XmlName);
			}else{
				error(XmlName);        
			};
		}
	};
	if(Timeout){
	var	timex=setInterval(function(){
			console.log("中断请求");
			XmlName.abort();
			clearInterval(timex);
		},Timeout);
		}
		}