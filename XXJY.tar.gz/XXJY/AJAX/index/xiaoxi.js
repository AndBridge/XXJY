var cLengtha;
var touserid;
var userid;
var msgArry;
var headpic
var thume=document.getElementsByClassName("thume")[0]
getUserid()
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
}
getToucherid()
function getToucherid(){
	touserid=sessionStorage.getItem("Touserid");
	name=sessionStorage.getItem("Name");
	msgArry=name.split(",")
	console.log(touserid)
	console.log(name)
	console.log(msgArry)
}
console.log(touserid)
Myajax("getUserContent","GET","http://manage.woyaoxuexue.com/guns/app/getuserinfo",
			{
				"userid":userid,
			},10000,function(msg){
				var stra=msg.responseText;
				/* console.log(stra); */
				var obja=eval("("+stra+")");			
				headpic=obja.data.headpic;
			},function(code){
				console.log(code.status);
			})

	Myajax("xiaoxi","GET","http://manage.woyaoxuexue.com/guns/app/getcommunicationlist",
	{
		"fromuserid":touserid,
		"touserid":userid,
		"fromuserphoto":msgArry[1],
		"fromusername":msgArry[0]
	},10000,function(msg){
		var chatlist=msg.responseText;
		var cLobj=eval("("+chatlist+")");
		console.log(cLobj)
		var cLength=cLobj.data.list.length;
		
     cLengtha=cLength;
		
	
	for(var i=0;i<cLength;i++){
		var content=cLobj.data.list[i].content;
		var fromuseridA=cLobj.data.list[i].fromuserid
		var sendtime=cLobj.data.list[i].sendtime
		// var them="<li class=\"thume\">"+fromuserid+"</li>"
		// $(".header>ul").append(them)
		var fromusernameA=cLobj.data.fromusername
			var fromuserphotoA=cLobj.data.fromuserphoto
		
		thume.innerHTML=fromusernameA
		if(userid==fromuseridA){
		
			var sendhtml="<ul class=\"chatUl\"><li><span>"+content+"</span><label><img height=\"100%\" width=\"100%\" src=\""+headpic+"\" >        </label></li></ul>"
			$(".main").append(sendhtml);
			
		}else if(touserid==fromuseridA){
			
			var chtyhtml="<ul class=\"chatmsg\"><li><span>"+content+"</span><label><img height=\"100%\" width=\"100%\" src=\""+fromuserphotoA+"\" ></label></li></ul>"
		$(".main").append(chtyhtml);
		
		}
		
	}
	
	},function(code){
		
	});
	var chattime=setInterval(function(){
	Myajax("xiaoxi","GET","http://manage.woyaoxuexue.com/guns/app/getcommunicationlist",
	{
		"fromuserid":touserid,
		"touserid":userid,
		"fromuserphoto":msgArry[1],
		"fromusername":msgArry[0]
	},10000,function(msg){
		var chatlist=msg.responseText;
		var cLobj=eval("("+chatlist+")");
		console.log(cLobj)
		var cLength=cLobj.data.list.length;
			console.log(cLength)
	/* 	if(cLength!=cLengtha){
			var content=cLobj.data[i].content;
			var fromuseridA=cLobj.data[i].fromuserid
			var sendtime=cLobj.data[i].sendtime
			// var them="<li class=\"thume\">"+fromuserid+"</li>"
			// $(".header>ul").append(them)
			
			if(userid==fromuseridA){
				
				var sendhtml="<ul class=\"chatUl\"><li><span>"+content+"</span><label></label></li></ul>"
				$(".main").append(sendhtml)
			}else if(touserid==fromuseridA){
				
				var chtyhtml="<ul class=\"chatmsg\"><li><span>"+content+"</span><label></label></li></ul>"
			$(".main").append(chtyhtml)
			
			}
		}
		 */
		
		
		if(cLength!=cLengtha){
			
		var i;
		
		for(i=0;i<cLength-1;i++){}
		console.log(i)
			var content=cLobj.data.list[i].content;
			console.log(content)
			var fromuseridA=cLobj.data.list[i].fromuserid
			var sendtime=cLobj.data.list[i].sendtime
			// var them="<li class=\"thume\">"+fromuserid+"</li>"
			// $(".header>ul").append(them)
			var fromusernameA=cLobj.data.fromusername
			var fromuserphotoA=cLobj.data.fromuserphoto
			if(userid==fromuseridA){
			
				var sendhtml="<ul class=\"chatUl\"><li><span>"+content+"</span><label><img height=\"100%\" width=\"100%\" src=\""+headpic+"\" >        </label></li></ul>"
				$(".main").append(sendhtml);
				
			}else if(touserid==fromuseridA){
				
				var chtyhtml="<ul class=\"chatmsg\"><li><span>"+content+"</span><label><img height=\"100%\" width=\"100%\" src=\""+fromuserphotoA+"\" ></label></li></ul>"
			$(".main").append(chtyhtml);
			
			}
			
			cLengtha=cLength
		
		
		}
		
		
	},function(code){
		
	});
},500);

window.onbeforeunload = function()
{ 
   window.clearInterval(chattime)
}


