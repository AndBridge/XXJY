var rows = 9999;//每页数据条数
var page = 1;
var maxpage;
var gradeid;
var courseid;
goodTeacher()
function goodTeacher(){
				//数据获取
				$.ajax({
						async:false,//同步，异步
						url:"http://manage.woyaoxuexue.com/guns/app/getyxmslist", //请求的服务端地址
						data:{
						"page":1,
						"rows":5
						},
						type:"get",
						dataType:"json",
						success:function(data){
						maxpage = data.data.navigateLastPage;
						//console.log(maxpage);
						var teacherNum=data.data.list.length;
						//console.log(teacherNum);//知道个数
						var teacherImg;//教师图片
						var teacherHtml;//教师具体界面
						var teacherName;//教师姓
						var teacherCourseid;//教师学科
						var teacherGradeid;//教师教授年级
						var teacherMark;//教师评分
						var teacherIntegrate;//教师授课课时数
						//var teacherBox = "<div href=\"javascript:void(0);\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd\"><img class=\"weui-media-box__thumb\" src=\""+teacherImg+"\"></div><div class=\"weui-media-box__bd weui-cell_access ziti\"> <a class=\"weui-cell__ft yxms\" href=\""+teacherHtml+"\"><span class=\"weui-media-box__title teacher\">"+teacherName+"</span><span class=\"weui-media-box__title subject\">"+teacherCourseid+"&nbsp;|&nbsp;</span><span class=\"weui-media-box__title grade\">"+teacherGradeid+"</span><sapn class=\"weui-media-box__title score\">评分：<img src=\""+teacherMark+"\" alt=\"\"/></span><span class=\"weui-media-box__title experience\">授课经验："+teacherIntegrate+"课时</span></a></div></div>";
						
						var i,j;
						for(i = 0;i < teacherNum;i++){
							teacherImg = data.data.list[i].photo;
							teacherHtml = "../Good_tea/tea_content.6.html";//需要修改
							teacherName = data.data.list[i].firstname + "老师";
						var id=data.data.list[i].id;
							//console.log(teacherName);
							//for(j = 0;j < data.data.list[i].courseid.length;j++){
								if(data.data.list[i].courseid[0]=="1"){
									teacherCourseid = "语文";
								}
								else if(data.data.list[i].courseid[0]=="2"){
									teacherCourseid = "数学";
								}
								else if(data.data.list[i].courseid[0]=="3"){
									teacherCourseid = "英语";
								}
								else if(data.data.list[i].courseid[0]=="4"){
									teacherCourseid = "物理";
								}
								else if(data.data.list[i].courseid[0]=="5"){
									teacherCourseid = "化学";
								}
								else if(data.data.list[i].courseid[0]=="6"){
									teacherCourseid = "生物";
								}
								else if(data.data.list[i].courseid[0]=="7"){
									teacherCourseid = "历史";
								}
								else if(data.data.list[i].courseid[0]=="8"){
									teacherCourseid = "地理";
								}
								else if(data.data.list[i].courseid[0]=="9"){
									teacherCourseid = "政治";
								}
							//}
							if(data.data.list[i].gradeid == "1"){
								teacherGradeid = "小学";
							}
							else if(data.data.list[i].gradeid == "2"){
								teacherGradeid = "初中";
							}
							else if(data.data.list[i].gradeid == "3"){
								teacherGradeid = "高中";
							}
							teacherIntegrate = data.data.list[i].integrate;
							if(data.data.list[i].mark == "5.00")
								teacherMark = "content/img/up_img/pingfen5.jpg";
							else if(data.data.list[i].mark == "4.00")
								teacherMark = "content/img/up_img/pingfen4.jpg";
							else if(data.data.list[i].mark == "3.00")
								teacherMark = "content/img/up_img/pingfen3.jpg";
							else if(data.data.list[i].mark == "2.00")
								teacherMark = "content/img/up_img/pingfen2.jpg";
							else if(data.data.list[i].mark == "1.00")
								teacherMark = "content/img/up_img/pingfen1.jpg";
								
				
							var teacherBoxA="<a name=\"NumberAuto\" onclick=\"holdId("+id+")\" href=\""+teacherHtml+"\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+teacherImg+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>"+teacherName+"</p></div><div class=\"subject_1\"><p>"+teacherCourseid+" | "+teacherGradeid+"</p></div><div class=\"tea_grade\"><span>评分：</span><img src=\""+teacherMark+"\" /></div><div class=\"exercise\"><p>授课经验："+teacherIntegrate+"课时</p></div></div></a>"
							$("#AutoNumber").append(teacherBoxA);
						
					
						}
						
						}
						});
						}
						
						
						$(window).scroll(
						        function() {
						            var scrollTop = $(this).scrollTop();
						            var scrollHeight = $(document).height();
						            var windowHeight = $(this).height();
						            if (scrollTop + windowHeight == scrollHeight) {
						                
						                if(page<=maxpage) {
											page++;
						                    goodTeacher();
										}
						                if(page==maxpage){
						                    $("#more").html("没有更多数据了");return false;
						                }
						                
						            }
						        });
	
	
	
	function holdId(Id){
		sessionStorage.removeItem("ID");
		//if (typeof(Storage) !== "undefined") {
	    // 存储
		console.log(Id);
	    sessionStorage.setItem("ID", Id);
		//}
		//var jsId = window.sessionStorage;
		//jsId = Id;
	}
	