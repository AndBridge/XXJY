var NES;
var	allchat;
var fromuserid;
var userid;
var cLengtha;
getUserid();
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
}

Myajax("chat","GET","http://manage.woyaoxuexue.com/guns/app/getlastmessagelist",
{
	"userid":userid
},10000,function(msg){
	
	var chatstr=msg.responseText;
	var chatobj=eval("("+chatstr+")")
	console.log(chatobj)
	var chatlength=chatobj.data.length;
	cLengtha=chatlength;
	for(var i=0 ;i<chatlength;i++){
		fromuserid=chatobj.data[i].fromuserid
		var content=chatobj.data[i].content
		var newmessage=chatobj.data[i].newmessage
		var sendtime=chatobj.data[i].sendtime
		var photo=chatobj.data[i].photo
		var name=chatobj.data[i].name
		console.log(fromuserid)
		console.log(content)
		console.log(newmessage)
		console.log(sendtime)
		NES=newmessage
		if(newmessage!=0){
			var redpeint="<span id=\"netss\" class=\"nets\">sss</span>"
			$("#redprintA").append(redpeint);
		}else if(newmessage==0){
			$("#netss").remove()
		}
		if(newmessage!=NES){
			var redpeint="<span id=\"netss\" class=\"nets\">sss</span>"
			$("#redprintA").append(redpeint);
			var content=chatobj.data[i].content
			var sendtime=chatobj.data[i].sendtime
		}else if(newmessage==0){
			$("#netss").remove()
		}
	
		var chathtml=" <div ontouchstart=\"gtouchstart("+userid+","+fromuserid+")\" ontouchmove=\"gtouchmove()\" class=\"chat2\"><a href=\"xiaoxi.html\" onclick=\"setTouserid("+fromuserid+",\'"+name+","+photo+"\')\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd\"><img class=\"weui-media-box__thumb\" src=\""+photo+"\"></div><div class=\"weui-media-box__bd\"><span class=\"newmsg\">"+newmessage+"</span><div class=\"chat_name\"><h4>"+name+"</h4><p id=\"SendT"+i+"\" class=\"weui-media-box__desc\">"+sendtime+"</p></div><div class=\"chat_content\"><p id=\"ContenD"+i+"\" class=\"weui-media-box__desc\">"+content+"</p></div></div></a></div>"
	$(".weui-panel__bd").append(chathtml)
	
	}
	
},function(code){
	
})

	
var lichat=setInterval(function(){
	
	
	Myajax("chat","GET","http://manage.woyaoxuexue.com/guns/app/getlastmessagelist",
	{
		"userid":userid
	},10000,function(msg){
		
		var chatstr=msg.responseText;
		var chatobj=eval("("+chatstr+")")
		console.log(chatobj)
		var chatlength=chatobj.data.length;
		
		
		if(chatlength!=cLengtha){
		
		var J;
		if(chatlength!=0){
		for(J=0;J<chatlength;J++){
			console.log(J)
			var fromuserid=chatobj.data[0].fromuserid
			var content=chatobj.data[0].content
			var newmessage=chatobj.data[0].newmessage
			var newmessageX=chatobj.data[J].newmessage
			var sendtime=chatobj.data[0].sendtime
			var photo=chatobj.data[0].photo
			var name=chatobj.data[0].name
			var chathtml=" <div ontouchstart=\"gtouchstart("+userid+","+fromuserid+")\" ontouchmove=\"gtouchmove()\" class=\"chat2\"><a href=\"xiaoxi.html\" onclick=\"setTouserid("+fromuserid+",\'"+name+","+photo+"\')\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd\"><img class=\"weui-media-box__thumb\" src=\""+photo+"\"></div><div class=\"weui-media-box__bd\"><span class=\"newmsg\">"+newmessage+"</span><div class=\"chat_name\"><h4>"+name+"</h4><p id=\"SendT"+J+"\" class=\"weui-media-box__desc\">"+sendtime+"</p></div><div class=\"chat_content\"><p id=\"ContenD"+J+"\" class=\"weui-media-box__desc\">"+content+"</p></div></div></a></div>"
		}
		if(newmessageX!=0){
			var redpeint="<span id=\"netss\" class=\"nets\">sss</span>"
			$("#redprintA").append(redpeint);
		}else if(newmessageX==0){
			$("#netss").remove()
		}
		// console.log(J)
		// var fromuserid=chatobj.data[0].fromuserid
		// var content=chatobj.data[0].content
		// var newmessage=chatobj.data[0].newmessage
		// var sendtime=chatobj.data[0].sendtime
		// var photo=chatobj.data[0].photo
		// var name=chatobj.data[0].name
		// var chathtml=" <div ontouchstart=\"gtouchstart("+userid+","+fromuserid+")\" ontouchmove=\"gtouchmove()\" class=\"chat2\"><a href=\"xiaoxi.html\" onclick=\"setTouserid("+fromuserid+",\'"+name+","+photo+"\')\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd\"><img class=\"weui-media-box__thumb\" src=\""+photo+"\"></div><div class=\"weui-media-box__bd\"><span class=\"newmsg\">"+newmessage+"</span><div class=\"chat_name\"><h4>"+name+"</h4><p id=\"SendT"+i+"\" class=\"weui-media-box__desc\">"+sendtime+"</p></div><div class=\"chat_content\"><p id=\"ContenD"+i+"\" class=\"weui-media-box__desc\">"+content+"</p></div></div></a></div>"
		
		$(".weui-panel__bd").append(chathtml)
			cLengtha=chatlength;
			}
			}
			if(chatlength!=0){
		var chatcont=setInterval(function(){
		
			var V;
		for(V=0;V<chatobj.data.length;V++){
			
		if(chatobj.data[V].newmessage!=NES){
			location.reload([true]);
			NES=newmessage
		// var content=chatobj.data[V].content
		// var newmessage=chatobj.data[V].newmessage
		// var sendtime=chatobj.data[V].sendtime
		// $(".newmsg").eq(V).empty();
		// $(".newmsg").eq(V).append(newmessage);
		// $("#SendT"+V+"").empty();
		// $("#SendT"+V+"").append(sendtime);
		// $("#ContenD"+V+"").empty();
		// $("#ContenD"+V+"").append(content);
		}
		}
		},200)
		}
		
			},function(code){
				
			})
			},5000)
	
	
	
	
	
	
	

	
	










	function setTouserid(touserid,name,photo){
	sessionStorage.removeItem("Touserid");
	sessionStorage.removeItem("Name");
	sessionStorage.removeItem("Photo");
	sessionStorage.setItem("Touserid", touserid);
	sessionStorage.setItem("Name", name);
	sessionStorage.setItem("Photo", photo);
	//}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	var timeOutEvent=0;//定时器
	//开始按   
	function gtouchstart(dropid,formid){   
		
	    timeOutEvent = setTimeout("longPress("+dropid+","+formid+")",500);//这里设置定时器，定义长按500毫秒触发长按事件，时间可以自己改，个人感觉500毫秒非常合适   
	    return false;   
	};   
	//手释放，如果在500毫秒内就释放，则取消长按事件，此时可以执行onclick应该执行的事件   
	function gtouchend(dropid){   
	    clearTimeout(timeOutEvent);//清除定时器   
	    if(timeOutEvent!=0){   
	        //这里写要执行的内容（尤如onclick事件）   
	        
	    }   
	    return false;   
	};   
	//如果手指有移动，则取消所有事件，此时说明用户只是要移动而不是长按   
	function gtouchmove(){   
	    clearTimeout(timeOutEvent);//清除定时器   
	    timeOutEvent = 0;   
	      
	};   
	   
	//真正长按后应该执行的内容   
	function longPress(dropid,formid){
		console.log(dropid)
		console.log(formid)
	    timeOutEvent = 0;   
	    //执行长按要执行的内容，如弹出菜单   
	    var flag=confirm("确认删除吗");
	    if(flag){
	    	Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/deleteusermessage",
	    	{
	    		"touserid":dropid,
				"fromuserid":formid,
				"userid":dropid
	    	},1000,function(msg){
				location.reload([true]);
			},function(code){
				
			})
	    }
	}   
	
	