GETNewid();
var Imga11=document.getElementsByClassName("imgax")[0];
var newsid;
function GETNewid(){
	newsid=sessionStorage.getItem("ID");
	//if (typeof(Storage) !== "undefined") {
    // 存储
	console.log(newsid);
	//}
	//var jsId = window.sessionStorage;
	//jsId = Id;
}

Myajax("GETnew","GET","http://manage.woyaoxuexue.com/guns/app/getnewsdetil",
{
	"newsid":newsid
},10000,function(msg){
	var str=msg.responseText;
	var obj=eval("("+str+")")
	console.log(obj)
	console.log(newsid);
	var content=obj.data.content;
	console.log(content);
	var newsimage=obj.data.newsimage;
	console.log(newsimage);
	var title=obj.data.title;
	/* var ImgHrl="<img src=\""+newsimage+"\">" */
	$(".titleH").append(title)
	$(".consulting_more").append(content)
	/* $(".imgax").append(ImgHrl) */
	var bannerFourth=document.getElementById("bannerFourth")
	bannerFourth.src=newsimage
	    /* Imga11.setAttribute("src",newsimage); */
	/* var LunboImage=" <ul><li class=\"lunbotu\"><a href=\"\"><img src=\"content/img/up_img/2008814183939909_2.jpg\" ></a></li><li class=\"lunbotu\"><a href=\"\"><img src=\"content/img/up_img/2786001_082828452000_2.jpg\" ></a></li><li class=\"lunbotu\"><a href=\"\"><img src=\"content/img/up_img/71X58PICNjx_1024.jpg\" ></a></li><li class=\"lunbotu\"><a href=\"\"><img src=\"content/img/up_img/9448607_145742365000_2.jpg\" ></a></li></ul>"; */
},function(code){
	console.log(code.status);
})