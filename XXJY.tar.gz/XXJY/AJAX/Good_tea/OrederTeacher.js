var id;
var listLength;
var j;
var price;
var courseid;
var gradeid;
var userid;
var teacherIDX;
var allMoney;
var classnum;
var orderid;
var teacherid;
GetuserID()
function GetuserID(){
    userid = localStorage.getItem("Userid");
	//id = Id;
	/* console.log(userid); */
	teacherid=localStorage.getItem("TecherId");
}
getTeacherOrederID()
function getTeacherOrederID(){
    orderid = sessionStorage.getItem("ID");
	//id = Id;
	console.log(orderid);
 			getTeacherOreder();
}


function getTeacherOreder(){
	/* console.log("1"); */
	Myajax("getTeacher","GET","http://manage.woyaoxuexue.com/guns/app/getmingshiorderdetail",
	{
		"page":1,
		"rows":9999,
		"orderid":orderid
	},100000,
	function(msg){
		var str=msg.responseText;
		/* console.log(str); */
		var obja=eval("("+str+")");
		console.log(obja);
		
		
		
		var firstname=obja.data.firstname;
		//console.log(firstname);
		/* var id=obja.data.id; */
		//console.log(id);
		teacherIDX=obja.data.userid;
		//console.log(userid);
		var addareaname=obja.data.addareaname;
		var addprovincename=obja.data.addprovincename;
		var addcityname=obja.data.addcityname;
		var address=obja.data.address;
		if(addprovincename=='undefined'){
			addprovincename=""
		}
		if(addcityname=='undefined'){
			addcityname=""
		}
		if(addareaname=='undefined'){
			addareaname=""
		}
		if(address==''){
			addareaname=""
		}
		if(address=='undefined'){
			addareaname=""
		}
		var headpic=obja.data.headpic;
		var useridChat=obja.data.teacherid;
		//console.log(photo);
		var sex=obja.data.sex;
		console.log(sex);
		courseid=obja.data.courseid;
		//console.log(courseid);
		var gradeid=obja.data.gradeid;
		/* console.log(gradeid); */
		var introduction=obja.data.introduction;
		//console.log(introduction);
		var integrate=obja.data.classnum;
		//console.log(integrate);
		price=obja.data.price;
		var amount=obja.data.amount;
		teacherid=obja.data.teacherid;
		/* console.log(price); */
		var teachplacetype=obja.data.teachplacetype;
		/* console.log(teachplacetype); */
		var ordertype=obja.data.ordertype;
		/*技能 转化 */
		
		if(courseid=="1"){
			courseid="语文";
		}else if(courseid=="2"){
			courseid="数学"
		}else if(courseid=="3"){
			courseid="英语"
		}else if(courseid=="4"){
			courseid="物理"
		}else if(courseid=="5"){
			courseid="化学"
		}else if(courseid=="6"){
			courseid="生物"
		}else if(courseid=="7"){
			courseid="历史"
		}else if(courseid=="8"){
			courseid="地理"
		}else if(courseid=="9"){
			courseid="政治"
		}else if(courseid=="10"){
			courseid="科学"
		}else if(courseid=="11"){
			courseid="音乐"
		}else if(courseid=="12"){
			courseid="美术"
		}else if(courseid=="13"){
			courseid="体育"
		}else if(courseid=="14"){
			courseid="信息"
		}else if(courseid=="0"){
			courseid="全学段"
		}
		//console.log(skillid)
		/* 性别转换 */
		
			if(sex=="1"){
			sex="男";
		}else if(sex=="2"){
			sex="女";
		}else if(sex=="0"){
			sex="无要求";
		}else{
			sex="出错了";
		}
		//console.log(sex)
		/* 上课方式转换 */		
			
		if(teachplacetype=="0"){
			teachplacetype="请老师上门";
		}else if(teachplacetype=="1"){
			teachplacetype="到老师指定地点";
		}else if(teachplacetype=="2"){
			teachplacetype="无要求";
		}
		/* 年级转换 */
		if(gradeid=="1"){
			gradeid="小学";
		}else if(gradeid=="2"){
			gradeid="初中";
		}else if(gradeid=="3"){
			gradeid="高中";
		}else if(gradeid=="0"){
			gradeid="全学段";
		}else{
			gradeid="出错了";
		}
		if(ssq==""){
			ssq="您没有填写地址，请核实您的授课方式"
		}
		if(!ssq){
			ssq="您没有填写地址，请核实您的授课方式"
		}
		if(ssq=="undefined undefined undefined"){
			ssq="您没有填写地址，请核实您的授课方式"
		}
		
		
		
		
		
		
		if ( ordertype== 0) {
			ordertype="订单已取消"
		var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul>";
		var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a onclick=\"ONUrl()\" ><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+headpic+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
		$(".banner").append(bannerChildren)
		$(".main").append(mainChilder);
		} else if ( ordertype== 1) {
			ordertype="确认订单"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a><br><br><a><button onclick=\"Admcondirm()\" type=\"button\">确认订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a onclick=\"ONUrl()\"><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+headpic+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
		} else if(ordertype== 2){
			ordertype="等待支付"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a><br><br><a><button  type=\"button\">等待支付</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a onclick=\"ONUrl()\"><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+headpic+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
		}else if(ordertype== 3){
			ordertype="订单已完成"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a onclick=\"ONUrl()\"><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+headpic+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
		}else if(ordertype== 4){
			ordertype="订单进行中"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a><br><br><a><button  type=\"button\">确认订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a onclick=\"ONUrl()\"><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+headpic+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
			}
		// }else if(ordertype== 5){
		// 	ordertype="订单待支付"
		// var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a><br><br><a><button type=\"button\">订单待支付</button></a>";
		// var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a onclick=\"ONUrl()\"><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+headpic+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
		// $(".banner").append(bannerChildren)
		// $(".main").append(mainChilder);
		// }
		
	
		
		
		
		
		
		/* var allmenoy;
		
		
		
		
		
		
		
		
		var ClassTime=document.getElementsByClassName("ClassTime");
			ClassTime.onmouseleave=function(){
			allmenoy=ClassTime.value*price;
			} */
		
			
	},function(code){
		console.log(code.status);
	}
	);
};


function cellPay(){
	
	Myajax("cellPay","GET","http://manage.woyaoxuexue.com/guns/app/teacherconfirmmingshiorder",
	{
		"orderid":orderid,
		"ordertype":0
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 var msgpay=objr.msg;
		 console.log(teacherIDX)
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("取消成功");
			 window.location.assign("../Mine/P_order2.html");
			 
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}





function condirm(){
	
	Myajax("condirm","GET","http://manage.woyaoxuexue.com/guns/app/teacherconfirmmingshiorder",
	{
		"orderid":orderid,
		"ordertype":5
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 console.log(orderid) 
		 var msgpay=objr.msg;
		 console.log(teacherIDX)
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("确认成功");
			 window.location.assign("../Mine/P_order2.html");
			 
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}

function Admcondirm(){
	console.log(orderid)
	Myajax("condirm","GET","http://manage.woyaoxuexue.com/guns/app/teacherconfirmmingshiorder",
	{
		"orderid":orderid,
		"ordertype":2
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 console.log(orderid) 
		 var msgpay=objr.msg;
		 console.log(teacherIDX)
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("确认成功");
			 window.location.assign("../Mine/P_order2.html");
			 
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}









function ONUrl(){
	if(getCookie("userid","/")){
	 		 window.location.assign("../Index/xiaoxi.html");
	}else{
	 		 window.location.assign("../Mine/login.1.html")
	}
}
function setTouserid(touserid,name,photo){
	sessionStorage.removeItem("Touserid");
	sessionStorage.removeItem("Name");
	sessionStorage.removeItem("Photo");
	sessionStorage.setItem("Touserid", touserid);
	sessionStorage.setItem("Name", name);
	sessionStorage.setItem("Photo", photo);
	//}
	}

